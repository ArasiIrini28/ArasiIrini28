"""Deterministic adapter contract tests. Fixtures are isolated from production."""
from datetime import timedelta
import httpx
from sqlalchemy import select
from backend.app import providers
from backend.app.models import SessionLocal, Cache, FetchLog, now
from backend.app.alerts import distance


def transport(monkeypatch, handler):
    original=httpx.Client
    monkeypatch.setattr(providers.settings,'provider_network_enabled',True)
    monkeypatch.setattr(providers.httpx,'Client',lambda **kwargs:original(transport=httpx.MockTransport(handler)))


def test_cache_and_stale(monkeypatch):
    transport(monkeypatch,lambda req:httpx.Response(200,json={'value':42}))
    with SessionLocal() as db:
        first=providers.fetch(db,'USGS','test','https://example.invalid')
        assert first['status']=='ok'
        assert providers.fetch(db,'USGS','test','https://example.invalid')['status']=='cached'
        row=db.scalar(select(Cache));row.expires=now()-timedelta(seconds=1);db.commit()
    # Restore mock factory using the original saved instance class, not the patched lambda.
    monkeypatch.undo()
    transport(monkeypatch,lambda req:httpx.Response(503))
    with SessionLocal() as db:
        stale=providers.fetch(db,'USGS','test','https://example.invalid')
        assert stale['status']=='stale' and stale['fetched_at']==first['fetched_at']
        assert providers.fetch(db,'USGS','test','https://example.invalid')['status']=='stale'


def test_failure_redacts_secret(monkeypatch):
    transport(monkeypatch,lambda req:httpx.Response(403))
    with SessionLocal() as db:
        result=providers.fetch(db,'NASA FIRMS','test','https://example.invalid/VERY_SECRET_KEY')
        assert result['status']=='unavailable' and result['data'] is None
        assert 'VERY_SECRET_KEY' not in str(result)
        assert 'VERY_SECRET_KEY' not in db.scalar(select(FetchLog)).detail


def test_usgs_parser(monkeypatch):
    payload={'features':[{'id':'test-eq','geometry':{'coordinates':[10,20,5]},'properties':{'mag':4.2,'place':'TEST EVENT','time':1000,'updated':2000,'url':'https://earthquake.usgs.gov/test'}}]}
    transport(monkeypatch,lambda req:httpx.Response(200,json=payload))
    with SessionLocal() as db:
        item=providers.earthquakes(db)['data'][0]
        assert item['depth_km']==5 and item['latitude']==20 and item['magnitude']==4.2


def test_firms_parser(monkeypatch):
    monkeypatch.setattr(providers.settings,'firms_map_key','TEST_KEY_ONLY')
    payload='latitude,longitude,acq_date,acq_time,confidence,frp,instrument\n10,20,2025-01-01,0030,n,4.2,VIIRS\n'
    transport(monkeypatch,lambda req:httpx.Response(200,text=payload))
    with SessionLocal() as db:
        item=providers.wildfires(db,10,20)['data'][0]
        assert item['time']=='2025-01-01T00:30:00Z' and item['confidence']=='n'


def test_gdacs_parser(monkeypatch):
    payload={'features':[{'geometry':{'type':'Point','coordinates':[10,20]},'properties':{'eventtype':'FL','eventid':12,'episodeid':1,'name':'TEST flood','fromdate':'2025-01-01','alertlevel':'Orange','url':{'report':'https://www.gdacs.org/test'}}}]}
    transport(monkeypatch,lambda req:httpx.Response(200,json=payload))
    with SessionLocal() as db:
        item=providers.disasters(db)['data'][0]
        assert item['severity']=='Orange' and item['id']=='FL-12-1'


def test_openaq_v3_sensor_join(monkeypatch):
    monkeypatch.setattr(providers.settings,'openaq_api_key','TEST_KEY_ONLY')
    def handler(req):
        assert req.headers['X-API-Key']=='TEST_KEY_ONLY'
        if req.url.path.endswith('/latest'):
            return httpx.Response(200,json={'results':[{'sensorsId':42,'value':12,'datetime':{'utc':'2025-01-01T00:00:00Z'}}]})
        return httpx.Response(200,json={'results':[{'id':1,'name':'TEST station','sensors':[{'id':42,'parameter':{'name':'pm25','units':'µg/m³'}}]}]})
    transport(monkeypatch,handler)
    with SessionLocal() as db:
        result=providers.air_quality(db,10,20,'observations')
        assert result['data'][0]['parameter']['name']=='pm25'
        assert result['data'][0]['station']=='TEST station'


def test_invalid_provider_payload_is_unavailable(monkeypatch):
    transport(monkeypatch,lambda req:httpx.Response(200,json={'unexpected':True}))
    with SessionLocal() as db:
        assert providers.earthquakes(db)['status']=='unavailable'


def test_great_circle_distance():
    assert distance(0,0,0,0)==0
    assert 110<distance(0,0,0,1)<112


def test_forecast_requests_ten_days(monkeypatch):
    def handler(req):
        assert req.url.params['forecast_days']=='10'
        assert 'precipitation_probability' in req.url.params['hourly']
        return httpx.Response(200,json={'current':{'time':'2025-01-01T00:00'},'daily':{'time':[]}})
    transport(monkeypatch,handler)
    with SessionLocal() as db:
        assert providers.weather(db,10,20)['available']


def test_radar_parser_uses_only_past_observations(monkeypatch):
    payload={'host':'https://tilecache.rainviewer.com','generated':1600,'radar':{'past':[{'time':1000,'path':'/v2/radar/1000'},{'time':1600,'path':'/v2/radar/1600'}],'nowcast':[{'time':2200,'path':'/paid/2200'}]}}
    transport(monkeypatch,lambda req:httpx.Response(200,json=payload))
    with SessionLocal() as db:
        result=providers.radar(db)
        assert result['available'] and len(result['data']['frames'])==2
        assert result['data']['frames'][0]['url']=='https://tilecache.rainviewer.com/v2/radar/1000/512/{z}/{x}/{y}/2/1_1.png'
        assert result['data']['maxzoom']==7


def test_radar_rejects_arbitrary_tile_hosts(monkeypatch):
    transport(monkeypatch,lambda req:httpx.Response(200,json={'host':'https://attacker.invalid','radar':{'past':[]}}))
    with SessionLocal() as db:
        assert providers.radar(db)['status']=='unavailable'


def test_disabled_network_never_calls_provider(monkeypatch):
    monkeypatch.setattr(providers.settings,'provider_network_enabled',False)
    def forbidden(*args,**kwargs):
        raise AssertionError('Network call made while verification pending')
    monkeypatch.setattr(providers.httpx,'Client',forbidden)
    with SessionLocal() as db:
        assert providers.radar(db)['status']=='verification_pending'
        assert providers.weather(db,10,20)['status']=='verification_pending'
