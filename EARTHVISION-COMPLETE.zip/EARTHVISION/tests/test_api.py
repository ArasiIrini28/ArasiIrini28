import pytest
from sqlalchemy import select, func
from backend.app.models import SessionLocal, Weather, Rainfall, Wind, User, Session
from backend.app import providers
from backend.app.main import requests


def test_health_and_openapi(client):
    assert client.get('/api/health').json()['database'] == 'connected'
    schema = client.get('/openapi.json').json()
    assert '/api/ml/train' in schema['paths']
    assert client.get('/api/does-not-exist').status_code == 404


@pytest.mark.parametrize('path',['/api/users/me','/api/alerts','/api/notifications','/api/locations','/api/users/preferences'])
def test_private_routes_require_auth(client,path):
    assert client.get(path).status_code == 401


def test_auth_lifecycle(account):
    assert account.get('/api/users/me').json()['name'] == 'Explorer'
    with SessionLocal() as db:
        user=db.scalar(select(User))
        assert user.password_hash.startswith('$argon2id$')
        assert 'Test-password' not in user.password_hash
        session=db.scalar(select(Session))
        assert session.token_hash != account.cookies.get('ev_session')
    assert account.post('/api/auth/logout',json={}).status_code == 200
    assert account.get('/api/users/me').status_code == 401
    assert account.post('/api/auth/login',json={'email':'explorer@example.org','password':'incorrect-password'}).status_code == 401
    assert account.post('/api/auth/login',json={'email':'explorer@example.org','password':'Test-password-984!'}).status_code == 200


def test_duplicate_invalid_registration(account):
    assert account.post('/api/auth/register',json={'email':'explorer@example.org','password':'Long-password-123'}).status_code == 409
    assert account.post('/api/auth/register',json={'email':'invalid','password':'short'}).status_code == 422


def test_csrf_content_type_and_cookie(account):
    assert account.post('/api/auth/logout',json={},headers={'Origin':'https://evil.invalid'}).status_code == 403
    assert account.post('/api/auth/logout',content='{}',headers={'Content-Type':'text/plain'}).status_code == 415
    response=account.post('/api/auth/login',json={'email':'explorer@example.org','password':'Test-password-984!'})
    assert 'HttpOnly' in response.headers['set-cookie']
    assert 'SameSite=lax' in response.headers['set-cookie']


def test_preferences_and_saved_locations(account):
    data={'theme':'light','units':'imperial','home_page':'weather'}
    assert account.put('/api/users/preferences',json=data).status_code == 200
    assert account.get('/api/users/preferences').json()['theme']=='light'
    place={'latitude':51.5,'longitude':-0.12,'name':'London'}
    first=account.post('/api/locations',json=place).json()
    account.post('/api/locations',json=place)
    assert len(account.get('/api/locations').json())==1
    assert account.delete('/api/locations/'+str(first['id'])).status_code==200
    assert account.get('/api/locations').json()==[]


def test_weather_persistence_and_dedup(client,monkeypatch,weather_fixture):
    monkeypatch.setattr(providers,'weather',lambda *args,**kwargs:weather_fixture)
    for _ in range(2):
        r=client.get('/api/weather?latitude=51&longitude=1')
        assert r.status_code == 200
    with SessionLocal() as db:
        assert db.scalar(select(func.count()).select_from(Weather))==1
        assert db.scalar(select(func.count()).select_from(Rainfall))==1
        assert db.scalar(select(func.count()).select_from(Wind))==1


@pytest.mark.parametrize('path',['/api/weather?latitude=91','/api/weather?longitude=-181','/api/weather?latitude=nan','/api/earthquakes?limit=5000','/api/weather/history?start=2024-02-01&end=2024-01-01','/api/satellite?day=1999-01-01'])
def test_validation(client,path):
    assert client.get(path).status_code==422


def test_alert_dedup_and_read(account,monkeypatch,weather_fixture):
    monkeypatch.setattr(providers,'weather',lambda *args:weather_fixture)
    sub=account.post('/api/alerts',json={'latitude':51,'longitude':1,'name':'Test location','kind':'temperature','threshold':35,'radius_km':100}).json()
    assert account.post('/api/alerts/check',json={}).json()['generated']==1
    assert account.post('/api/alerts/check',json={}).json()['generated']==0
    notes=account.get('/api/notifications').json()
    assert len(notes)==1 and not notes[0]['read']
    assert account.patch(f"/api/notifications/{notes[0]['id']}/read",json={}).json()['read']
    account.delete(f"/api/alerts/{sub['id']}")
    assert account.get('/api/notifications').json()==[]


def test_stale_data_never_alerts(account,monkeypatch,weather_fixture):
    weather_fixture['status']='stale'
    monkeypatch.setattr(providers,'weather',lambda *args:weather_fixture)
    account.post('/api/alerts',json={'latitude':1,'longitude':1,'name':'Test','kind':'temperature','threshold':30})
    assert account.post('/api/alerts/check',json={}).json()=={'checked':1,'generated':0,'unavailable':1}


def test_ownership_isolation(account):
    place={'latitude':1,'longitude':1,'name':'Test','kind':'earthquake','threshold':4}
    sub=account.post('/api/alerts',json=place).json()
    account.post('/api/auth/logout',json={})
    account.post('/api/auth/register',json={'email':'other@example.org','password':'Another-password-12'})
    assert account.get('/api/alerts').json()==[]
    assert account.delete(f"/api/alerts/{sub['id']}").status_code==404


def test_reports_are_attributed(client,monkeypatch,weather_fixture):
    monkeypatch.setattr(providers,'weather',lambda *args:weather_fixture)
    suffix='?start=2025-01-01&end=2025-01-02'
    csv=client.get('/api/reports/csv'+suffix)
    assert csv.status_code==200 and 'Open-Meteo' in csv.text and 'fetched_at' in csv.text
    pdf=client.get('/api/reports/pdf'+suffix)
    assert pdf.status_code==200 and pdf.content.startswith(b'%PDF')
    assert client.get('/api/analytics'+suffix).json()['trends']['temp_max']['slope_per_day']>0


def test_missing_keys_explicit(client,monkeypatch):
    monkeypatch.setattr(providers.settings,'firms_map_key','')
    monkeypatch.setattr(providers.settings,'openaq_api_key','')
    assert client.get('/api/wildfires').json()['status']=='key_required'
    assert client.get('/api/air-quality?mode=observations').json()['status']=='key_required'


def test_auth_rate_limit(client):
    requests.clear()
    for _ in range(15):
        client.post('/api/auth/login',json={})
    assert client.post('/api/auth/login',json={}).status_code==429


def test_notification_websocket(account):
    with account.websocket_connect('/api/ws/notifications',headers={'Origin':'http://localhost:8000'}) as ws:
        assert ws.receive_json()=={'unread':0}


def test_ml_endpoint_real_evaluation(client):
    result=client.get('/api/ml/predict').json()
    assert result['prediction']['date']=='2016-01-01'
    assert result['test'][result['selected_model']]['mae']>0
    assert 'historical' in result['source']
