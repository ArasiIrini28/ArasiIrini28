"""Fixtures are TEST-ONLY; runtime code never uses invented environmental data."""
import os
from pathlib import Path
import tempfile
import pytest

os.environ['DATABASE_URL'] = 'sqlite:///' + str(Path(tempfile.mkdtemp(prefix='earthvision-tests-')) / 'tests.db')
os.environ['SCHEDULER_ENABLED'] = 'false'
os.environ['RATE_LIMIT'] = '10000'
os.environ['PROVIDER_NETWORK_ENABLED'] = 'false'
from fastapi.testclient import TestClient
from backend.app.main import app, requests
from backend.app.models import Base, engine, SessionLocal
from backend.app.storage import seed


@pytest.fixture(autouse=True)
def reset_database():
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        seed(db)
    requests.clear()
    yield


@pytest.fixture
def client():
    with TestClient(app) as c:
        yield c


@pytest.fixture
def account(client):
    result = client.post('/api/auth/register', json={'email':'explorer@example.org','name':'Explorer','password':'Test-password-984!'} )
    assert result.status_code == 201
    return client


@pytest.fixture
def weather_fixture():
    return {'provider':'Open-Meteo','kind':'model forecast','status':'ok','available':True,
            'fetched_at':'2025-01-01T00:00:00Z','source_time':'2025-01-01T00:00','attribution':'TEST FIXTURE ONLY','message':None,
            'data':{'current':{'time':'2025-01-01T00:00','temperature_2m':40.0,'precipitation':2.0,
                               'wind_speed_10m':15.0,'wind_direction_10m':180,'cloud_cover':20,'relative_humidity_2m':60},
                    'daily':{'time':['2025-01-01','2025-01-02'],'temperature_2m_max':[20.0,22.0],
                             'temperature_2m_min':[10.0,11.0],'precipitation_sum':[1.0,0.0],'wind_speed_10m_max':[15.0,16.0]}}}
