import numpy as np
import pytest
from ml.pipeline import prepare, evaluate, reference, anomalies


def test_real_dataset_chronological_split_and_baseline():
    result=evaluate(reference(),'Real Seattle archive')
    split=result['split']
    assert split['train'][1]<split['validation'][0]<split['validation'][1]<split['test'][0]
    assert sum(v[2] for v in split.values())==1453
    assert 'persistence' in result['validation']
    assert result['selected_model']==min(result['validation'],key=lambda k:result['validation'][k]['mae'])
    for values in result['test'].values():
        assert np.isfinite(list(values.values())).all()


def test_feature_rows_do_not_depend_on_future_values():
    data=reference()
    _,before,_,_=prepare(data)
    data.loc[100:,'temp_max']=999
    _,after,_,_=prepare(data)
    assert before.iloc[:100].equals(after.iloc[:100])


def test_missing_or_nonconsecutive_data_rejected():
    with pytest.raises(ValueError):
        evaluate(reference().iloc[:20],'test')
    with pytest.raises(ValueError):
        evaluate(reference().drop(index=40),'test')


def test_anomaly_reference_precedes_evaluation():
    result=anomalies(reference())
    assert result['evaluated']==439
    assert all(row['date']>result['reference_end'] for row in result['items'])
