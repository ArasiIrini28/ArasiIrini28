-- EarthVision v1 schema; generated for review. Normal startup uses Alembic.


CREATE TABLE api_fetch_logs (
	provider VARCHAR(80) NOT NULL, 
	status VARCHAR(30) NOT NULL, 
	detail VARCHAR(200) NOT NULL, 
	id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id)
)

;

CREATE INDEX ix_api_fetch_logs_created_at ON api_fetch_logs (created_at);

CREATE INDEX ix_api_fetch_logs_provider ON api_fetch_logs (provider);


CREATE TABLE data_sources (
	name VARCHAR(80) NOT NULL, 
	url VARCHAR(500) NOT NULL, 
	license VARCHAR(500) NOT NULL, 
	id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (name)
)

;

CREATE INDEX ix_data_sources_created_at ON data_sources (created_at);


CREATE TABLE locations (
	name VARCHAR(150) NOT NULL, 
	latitude FLOAT NOT NULL, 
	longitude FLOAT NOT NULL, 
	id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (latitude, longitude)
)

;

CREATE INDEX ix_locations_created_at ON locations (created_at);


CREATE TABLE ml_models (
	fingerprint VARCHAR(64) NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	metrics JSON NOT NULL, 
	id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (fingerprint)
)

;

CREATE INDEX ix_ml_models_created_at ON ml_models (created_at);


CREATE TABLE provider_cache (
	"key" VARCHAR(64) NOT NULL, 
	payload JSON NOT NULL, 
	expires DATETIME NOT NULL, 
	id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE ("key")
)

;

CREATE INDEX ix_provider_cache_expires ON provider_cache (expires);

CREATE INDEX ix_provider_cache_created_at ON provider_cache (created_at);


CREATE TABLE users (
	email VARCHAR(254) NOT NULL, 
	password_hash VARCHAR(255) NOT NULL, 
	name VARCHAR(80) NOT NULL, 
	id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (email)
)

;

CREATE INDEX ix_users_created_at ON users (created_at);


CREATE TABLE air_quality (
	location_id INTEGER NOT NULL, 
	source_id INTEGER NOT NULL, 
	observed_at VARCHAR(40) NOT NULL, 
	parameter VARCHAR(40) NOT NULL, 
	value FLOAT NOT NULL, 
	unit VARCHAR(30) NOT NULL, 
	sensor VARCHAR(80) NOT NULL, 
	id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (location_id, source_id, observed_at, parameter, sensor), 
	FOREIGN KEY(location_id) REFERENCES locations (id), 
	FOREIGN KEY(source_id) REFERENCES data_sources (id)
)

;

CREATE INDEX ix_air_quality_created_at ON air_quality (created_at);

CREATE INDEX ix_air_quality_location_id ON air_quality (location_id);


CREATE TABLE alert_subscriptions (
	user_id INTEGER NOT NULL, 
	location_id INTEGER NOT NULL, 
	kind VARCHAR(20) NOT NULL, 
	threshold FLOAT NOT NULL, 
	radius_km FLOAT NOT NULL, 
	enabled BOOLEAN NOT NULL, 
	id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE CASCADE, 
	FOREIGN KEY(location_id) REFERENCES locations (id)
)

;

CREATE INDEX ix_alert_subscriptions_user_id ON alert_subscriptions (user_id);

CREATE INDEX ix_alert_subscriptions_created_at ON alert_subscriptions (created_at);


CREATE TABLE audit_logs (
	user_id INTEGER, 
	action VARCHAR(80) NOT NULL, 
	id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE SET NULL
)

;

CREATE INDEX ix_audit_logs_created_at ON audit_logs (created_at);


CREATE TABLE disaster_events (
	external_id VARCHAR(190) NOT NULL, 
	source_id INTEGER NOT NULL, 
	latitude FLOAT NOT NULL, 
	longitude FLOAT NOT NULL, 
	event_time VARCHAR(60) NOT NULL, 
	title VARCHAR(500) NOT NULL, 
	details JSON NOT NULL, 
	id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (external_id), 
	FOREIGN KEY(source_id) REFERENCES data_sources (id)
)

;

CREATE INDEX ix_disaster_events_event_time ON disaster_events (event_time);

CREATE INDEX ix_disaster_events_created_at ON disaster_events (created_at);


CREATE TABLE earthquakes (
	external_id VARCHAR(190) NOT NULL, 
	source_id INTEGER NOT NULL, 
	latitude FLOAT NOT NULL, 
	longitude FLOAT NOT NULL, 
	event_time VARCHAR(60) NOT NULL, 
	title VARCHAR(500) NOT NULL, 
	details JSON NOT NULL, 
	id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (external_id), 
	FOREIGN KEY(source_id) REFERENCES data_sources (id)
)

;

CREATE INDEX ix_earthquakes_event_time ON earthquakes (event_time);

CREATE INDEX ix_earthquakes_created_at ON earthquakes (created_at);


CREATE TABLE ml_predictions (
	model_id INTEGER NOT NULL, 
	target_date VARCHAR(30) NOT NULL, 
	value FLOAT NOT NULL, 
	id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (model_id, target_date), 
	FOREIGN KEY(model_id) REFERENCES ml_models (id)
)

;

CREATE INDEX ix_ml_predictions_created_at ON ml_predictions (created_at);


CREATE TABLE satellite_layers (
	identifier VARCHAR(150) NOT NULL, 
	title VARCHAR(150) NOT NULL, 
	source_id INTEGER NOT NULL, 
	template VARCHAR(500) NOT NULL, 
	id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (identifier), 
	FOREIGN KEY(source_id) REFERENCES data_sources (id)
)

;

CREATE INDEX ix_satellite_layers_created_at ON satellite_layers (created_at);


CREATE TABLE saved_locations (
	user_id INTEGER NOT NULL, 
	location_id INTEGER NOT NULL, 
	id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (user_id, location_id), 
	FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE CASCADE, 
	FOREIGN KEY(location_id) REFERENCES locations (id)
)

;

CREATE INDEX ix_saved_locations_user_id ON saved_locations (user_id);

CREATE INDEX ix_saved_locations_created_at ON saved_locations (created_at);


CREATE TABLE sessions (
	token_hash VARCHAR(64) NOT NULL, 
	user_id INTEGER NOT NULL, 
	expires DATETIME NOT NULL, 
	id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (token_hash), 
	FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE CASCADE
)

;

CREATE INDEX ix_sessions_created_at ON sessions (created_at);

CREATE INDEX ix_sessions_user_id ON sessions (user_id);

CREATE INDEX ix_sessions_expires ON sessions (expires);


CREATE TABLE user_preferences (
	user_id INTEGER NOT NULL, 
	theme VARCHAR(10) NOT NULL, 
	units VARCHAR(10) NOT NULL, 
	home_page VARCHAR(30) NOT NULL, 
	id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (user_id), 
	FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE CASCADE
)

;

CREATE INDEX ix_user_preferences_created_at ON user_preferences (created_at);


CREATE TABLE weather_data (
	location_id INTEGER NOT NULL, 
	source_id INTEGER NOT NULL, 
	observed_at VARCHAR(40) NOT NULL, 
	kind VARCHAR(24) NOT NULL, 
	temperature FLOAT, 
	humidity FLOAT, 
	cloud_cover FLOAT, 
	id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (location_id, source_id, observed_at, kind), 
	FOREIGN KEY(location_id) REFERENCES locations (id), 
	FOREIGN KEY(source_id) REFERENCES data_sources (id)
)

;

CREATE INDEX ix_weather_data_location_id ON weather_data (location_id);

CREATE INDEX ix_weather_data_created_at ON weather_data (created_at);


CREATE TABLE wildfires (
	external_id VARCHAR(190) NOT NULL, 
	source_id INTEGER NOT NULL, 
	latitude FLOAT NOT NULL, 
	longitude FLOAT NOT NULL, 
	event_time VARCHAR(60) NOT NULL, 
	title VARCHAR(500) NOT NULL, 
	details JSON NOT NULL, 
	id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (external_id), 
	FOREIGN KEY(source_id) REFERENCES data_sources (id)
)

;

CREATE INDEX ix_wildfires_created_at ON wildfires (created_at);

CREATE INDEX ix_wildfires_event_time ON wildfires (event_time);


CREATE TABLE notification_logs (
	user_id INTEGER NOT NULL, 
	subscription_id INTEGER NOT NULL, 
	event_key VARCHAR(190) NOT NULL, 
	message TEXT NOT NULL, 
	source VARCHAR(80) NOT NULL, 
	read BOOLEAN NOT NULL, 
	id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (subscription_id, event_key), 
	FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE CASCADE, 
	FOREIGN KEY(subscription_id) REFERENCES alert_subscriptions (id) ON DELETE CASCADE
)

;

CREATE INDEX ix_notification_logs_created_at ON notification_logs (created_at);

CREATE INDEX ix_notification_logs_user_id ON notification_logs (user_id);


CREATE TABLE rainfall_data (
	weather_id INTEGER NOT NULL, 
	millimeters FLOAT, 
	id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (weather_id), 
	FOREIGN KEY(weather_id) REFERENCES weather_data (id) ON DELETE CASCADE
)

;

CREATE INDEX ix_rainfall_data_created_at ON rainfall_data (created_at);


CREATE TABLE wind_data (
	weather_id INTEGER NOT NULL, 
	speed_kmh FLOAT, 
	direction FLOAT, 
	id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (weather_id), 
	FOREIGN KEY(weather_id) REFERENCES weather_data (id) ON DELETE CASCADE
)

;

CREATE INDEX ix_wind_data_created_at ON wind_data (created_at);
