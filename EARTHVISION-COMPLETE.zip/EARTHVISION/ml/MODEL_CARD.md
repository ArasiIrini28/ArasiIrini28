# EarthVision temperature benchmark

**Task:** predict next day's maximum temperature in °C. **Purpose:** academic evaluation of a small tabular model, not official forecasting or emergency decisions.

## Data

Bundled real daily Seattle weather: 2012-01-01 through 2015-12-31, 1,461 rows, via Vega datasets (NOAA source). Columns: date, precipitation (mm), temp_max/temp_min (°C), wind (m/s), categorical weather. Categorical weather is not used in the model. Geographic transfer is not claimed. Provenance and SHA-256 are in `data/PROVENANCE.md`.

## Features and target

The features at day t are its maximum/minimum temperature, precipitation, wind, temperature lags 1/2/7 days, trailing seven-day maximum-temperature mean, and sine/cosine calendar season for t+1. The target is maximum temperature on t+1. No target-day weather or future measurement is a feature. Missing initial lag rows and the final unobserved target are excluded, leaving 1,453 supervised examples.

Chronological split: 1,017 training, 218 validation, 218 test. A persistence baseline predicts tomorrow's maximum as today's maximum. Ridge uses a StandardScaler fitted only on the training data and fixed alpha 10. Random Forest uses 120 trees, max depth 8, minimum leaf 5, fixed seed 42. Lowest **validation MAE** selects the model, including the baseline. The held-out test is reported once for the selected model and persistence. Refit on all supervised rows occurs only afterward to produce the next-date estimate.

## Executed reference evaluation

Run `python -m ml.pipeline` to reproduce `evaluation.json`. Ridge was selected. Held-out test MAE **2.1010°C**, RMSE **2.6514°C**, R² **0.8936**; persistence MAE **2.2514°C**, RMSE **2.9302°C**, R² **0.8701**. Test targets span 2015-05-28 through 2015-12-31. The refitted next-day estimate is **5.71°C for 2016-01-01**. It is historical, not today's forecast. Exact results and predictions are stored in `evaluation.json`; no unsupported confidence interval is displayed.

## Anomalies and trends

Isolation Forest fits the earlier 70% of measurements, with 5% training contamination, and scores the remaining 30%. A temperature z-score references the training mean/standard deviation. There are no anomaly ground-truth labels, so precision/recall is **not claimed**. Seasonality can be detected as unusualness. Trends are least-squares slopes over the selected record period, not climate attribution; changing seasons can dominate them.

## Live-location training

Authenticated training fetches actual daily maximum/minimum temperature, precipitation and wind from Open-Meteo archive with the same chronological split. Archive wind is km/h (the reference CSV uses m/s); each model is fitted separately and never mixes those datasets. At least 180 consecutive records are required; nulls are excluded, not fabricated. Since archive availability lags, the next target date can still be in the past. The UI displays the actual target date.

## Limits

Small dataset, single reference location, no calibrated intervals, no operational forecast comparison, no causal interpretation, and no guarantee of performance under climate shifts or other geographies. No model deserialization endpoint is provided; the API never loads uploaded pickle/joblib files. Dataset fingerprints, split dates, metrics and source strings are persisted for reproducibility.
