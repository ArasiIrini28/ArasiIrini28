"""Leakage-safe next-day maximum-temperature benchmark and anomaly analysis."""
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor, IsolationForest
from sklearn.linear_model import Ridge
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

DATA = Path(__file__).parent / 'data' / 'seattle-weather.csv'


def metrics(actual, predicted):
    return {'mae': round(float(mean_absolute_error(actual, predicted)), 4),
            'rmse': round(float(np.sqrt(mean_squared_error(actual, predicted))), 4),
            'r2': round(float(r2_score(actual, predicted)), 4)}


def prepare(frame):
    df = frame.copy().sort_values('date').reset_index(drop=True)
    df['date'] = pd.to_datetime(df['date'])
    if df['date'].duplicated().any() or not df['date'].diff().dropna().eq(pd.Timedelta(days=1)).all():
        raise ValueError('Training data must contain unique, consecutive daily dates.')
    if len(df) < 180:
        raise ValueError('At least 180 consecutive daily records are required.')
    # Every feature is available by the end of day t. Target is t+1.
    x = df[['temp_max', 'temp_min', 'precipitation', 'wind']].astype(float).copy()
    for lag in (1, 2, 7):
        x[f'lag_{lag}'] = df['temp_max'].shift(lag)
    x['rolling_7'] = df['temp_max'].rolling(7).mean()
    target_dates = df['date'] + pd.Timedelta(days=1)
    x['season_sin'] = np.sin(2 * np.pi * target_dates.dt.dayofyear / 365.25)
    x['season_cos'] = np.cos(2 * np.pi * target_dates.dt.dayofyear / 365.25)
    y = df['temp_max'].shift(-1)
    valid = x.notna().all(axis=1) & y.notna()
    return df, x, y, valid


def evaluate(frame, provenance):
    df, features, targets, valid = prepare(frame)
    x, y = features[valid], targets[valid]
    n = len(x)
    a, b = int(n * .70), int(n * .85)
    train, validation, test = slice(0, a), slice(a, b), slice(b, n)
    models = {'ridge': make_pipeline(StandardScaler(), Ridge(alpha=10)),
              'random_forest': RandomForestRegressor(n_estimators=120, max_depth=8, min_samples_leaf=5, random_state=42, n_jobs=1)}
    validation_scores = {'persistence': metrics(y.iloc[validation], x.iloc[validation]['temp_max'])}
    for name, model in models.items():
        model.fit(x.iloc[train], y.iloc[train])
        validation_scores[name] = metrics(y.iloc[validation], model.predict(x.iloc[validation]))
    winner = min(validation_scores, key=lambda name: validation_scores[name]['mae'])
    # No hyperparameter/model selection uses the held-out test set.
    predictions = x.iloc[test]['temp_max'].to_numpy() if winner == 'persistence' else models[winner].predict(x.iloc[test])
    test_scores = {winner: metrics(y.iloc[test], predictions), 'persistence': metrics(y.iloc[test], x.iloc[test]['temp_max'])}
    if features.iloc[-1].isna().any():
        raise ValueError('The most recent input day has missing measurements.')
    next_value = float(features.iloc[-1]['temp_max'])
    if winner != 'persistence':
        # Refit only AFTER reporting frozen held-out evaluation.
        models[winner].fit(x, y)
        next_value = float(models[winner].predict(features.iloc[[-1]])[0])
    fingerprint = hashlib.sha256(frame.to_csv(index=False).encode()).hexdigest()
    dates = (df.loc[valid, 'date'] + pd.Timedelta(days=1)).dt.strftime('%Y-%m-%d').tolist()
    return {'fingerprint': fingerprint, 'source': provenance, 'target': 'Next-day maximum temperature (°C)',
            'selected_model': winner, 'selection': 'Lowest validation MAE, including persistence',
            'split': {'train': [dates[0], dates[a-1], a], 'validation': [dates[a], dates[b-1], b-a], 'test': [dates[b], dates[-1], n-b]},
            'validation': validation_scores, 'test': test_scores,
            'prediction': {'date': str((df['date'].iloc[-1] + pd.Timedelta(days=1)).date()), 'value': round(next_value, 2)},
            'series': [{'date': day, 'actual': float(actual), 'predicted': float(predicted)} for day, actual, predicted in zip(dates[b:], y.iloc[test], predictions)],
            'limitations': 'Research benchmark, not an official forecast. One location; no spatial generalization. Test residuals are not calibrated uncertainty. The bundled dataset ends in 2015; its next-day prediction is historical, never live.'}


def anomalies(frame):
    df = frame.copy().dropna(subset=['temp_max', 'precipitation', 'wind'])
    if len(df) < 60:
        raise ValueError('At least 60 valid daily observations are required.')
    # Reference fit uses the earlier 70%; score later records out of sample.
    boundary = int(len(df) * .7)
    train = df.iloc[:boundary]
    values = ['temp_max', 'precipitation', 'wind']
    model = IsolationForest(contamination=.05, random_state=42).fit(train[values])
    recent = df.iloc[boundary:].copy()
    recent['score'] = model.decision_function(recent[values])
    recent['unusual'] = model.predict(recent[values]) == -1
    # Temperature anomaly relative to training distribution, not a climate normal.
    mean, std = float(train.temp_max.mean()), float(train.temp_max.std())
    recent['z_score'] = (recent.temp_max - mean) / (std or 1)
    return {'method': 'Isolation Forest; earlier 70% reference; 5% reference contamination',
            'reference_end': str(train['date'].iloc[-1]), 'evaluated': len(recent),
            'items': recent[recent.unusual].replace({np.nan: None}).to_dict('records'),
            'limitation': 'Statistical unusualness is not a hazard warning. Seasonal variation can be flagged.'}


def trends(frame):
    result = {}
    for column, unit in [('temp_max', '°C/day'), ('precipitation', 'mm/day per day'), ('wind', 'source speed units/day')]:
        values = frame[column].to_numpy(dtype=float)
        mask = np.isfinite(values)
        result[column] = {'slope_per_day': float(np.polyfit(np.arange(len(values))[mask], values[mask], 1)[0]) if mask.sum() > 1 else None,
                          'mean': float(np.mean(values[mask])) if mask.any() else None, 'unit': unit}
    return result


def reference():
    return pd.read_csv(DATA)


if __name__ == '__main__':
    result = evaluate(reference(), 'Seattle weather, 2012–2015; Vega datasets / NOAA')
    path = Path(__file__).parent / 'evaluation.json'
    path.write_text(json.dumps(result, indent=2))
    print(json.dumps({k: result[k] for k in ('selected_model', 'split', 'validation', 'test', 'prediction')}, indent=2))
