# Seattle historical reference data

Downloaded 2026-11-05 from:
https://raw.githubusercontent.com/vega/vega-datasets/main/data/seattle-weather.csv

Vega datasets identifies NOAA as the Seattle weather source. The file contains real daily historical records (2012–2015), not synthetic samples. The accompanying Vega repository distributes datasets for visualization; underlying NOAA US-government weather measurements are public data. Credit NOAA and Vega datasets. See https://github.com/vega/vega-datasets for dataset metadata and license details.

SHA-256: `0845078a290b48e3149ab8639966824110a251db4e06fc144c06ebb534af23be`

Columns: date; precipitation (mm); maximum/minimum temperature (°C); wind (m/s); weather category. No personal data. Used only for a clearly labelled historical ML benchmark, never injected into live weather endpoints.
