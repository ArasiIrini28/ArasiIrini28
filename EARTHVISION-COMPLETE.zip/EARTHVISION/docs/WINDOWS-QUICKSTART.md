# EarthVision on Windows — beginner setup

1. Right-click `EARTHVISION-COMPLETE.zip` and choose **Extract All**. Use a short writable path, for example `C:\Projects\EarthVision`. Open the extracted `EARTHVISION` folder. Do not run from inside the ZIP viewer.
2. Install free **64-bit Python 3.12 or 3.13** from https://www.python.org/downloads/windows/. Enable **Add Python to PATH**. Install free **Node.js 24 LTS** from https://nodejs.org/ (npm is included). No MySQL or Docker is required for the default setup.
3. Double-click **`start.bat`**. Alternatively open PowerShell in the folder and run `py -3 scripts\start.py`. A Python virtual environment is created locally. The first installation needs access to PyPI and npm and may take several minutes.
4. Wait for `Uvicorn running on http://127.0.0.1:8000`. Open **http://localhost:8000** in Chrome, Edge or Firefox. API docs are at **http://localhost:8000/docs**.
5. The built-in country map, accounts, saved places, alerts setup and the real historical Seattle ML benchmark work locally. **Live-provider verification is PENDING**, so `.env` defaults to `PROVIDER_NETWORK_ENABLED=false`. Blank environmental values are intentional and never fabricated.
6. Once the restricted allowlist has been confirmed, run `.venv\Scripts\python.exe scripts\verify_providers.py` and inspect `docs\provider-verification.json`. This command really contacts providers; do **not** run it before that confirmation. Then set `PROVIDER_NETWORK_ENABLED=true` in `.env` to enable data requests and restart. Radar additionally needs `api.rainviewer.com` and `tilecache.rainviewer.com`.
7. Optional free FIRMS/OpenAQ keys go only in `.env`. Do not paste keys into the browser code, Git or chat. No payment details are needed for the supported local path.
8. Create an account from **Profile & preferences**. The password must be at least 10 characters. The account and preferences stay in your local SQLite database. No pre-created account is included.
9. Stop with **Ctrl+C** in the terminal. Keep `earthvision.db` to preserve accounts and preferences. Double-click `start.bat` to restart; after setup you can start without reinstalling using `.venv\Scripts\python.exe -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8000` from the project folder.

## Run tests

From PowerShell in `EARTHVISION`:

```powershell
.venv\Scripts\python.exe -m pytest -q
.venv\Scripts\python.exe -m ruff check backend ml workers tests scripts
cd frontend
npm run lint
npm test
npm run build
```

For browser tests, keep a separate QA server running against a disposable database, install free Playwright Chromium with `npx playwright install chromium`, then run `npm run test:e2e`. These tests register test accounts and should not target an important personal database.

## Verify the download

The adjacent `.sha256` file contains the archive checksum. In PowerShell:

```powershell
Get-FileHash .\EARTHVISION-COMPLETE.zip -Algorithm SHA256
```

Compare the full hash with `EARTHVISION-COMPLETE.zip.sha256`. The ZIP also contains a `MANIFEST.sha256` listing every delivered file. If Windows reports a corrupt archive, download again and compare checksums before extracting.

No Windows machine was available in the development environment, so the batch launcher is provided but not claimed to have been executed on Windows. Its cross-platform Python installation/startup logic and the Linux runtime were tested. See `VERIFICATION.md` for the actual evidence.
