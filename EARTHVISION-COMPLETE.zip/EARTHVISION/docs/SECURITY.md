# Security and reliability

- Argon2id password hashing with fresh salts; no plaintext passwords or default accounts.
- 32-byte random opaque session tokens in HttpOnly/SameSite=Lax cookies; only SHA-256 token hashes stored. Seven-day expiry; logout revokes the server session. Public HTTPS deployments must set `COOKIE_SECURE=true`.
- Authenticated routes derive ownership from the session, never from a submitted user ID. Notification, subscription and saved-location changes filter by owner. Cross-user tests cover this behavior.
- JSON-only mutations plus Origin validation and explicit CORS allowlists mitigate browser CSRF. WebSockets require an allowed Origin and revalidate the session at each unread-count update.
- Per-process API request limits (120/min default; auth 15/min); no trust in arbitrary forwarded IP headers. Nginx can add an outer limit for the full local stack. This is not a distributed rate limiter; scale requires reviewed shared limits.
- Pydantic range/length validation; bounded event pages, date ranges, request sizes and per-user subscription counts. Parameterized SQLAlchemy queries. HTTPS-only external links and text-only map popups.
- Credentials remain in backend environment configuration. FIRMS URLs contain a key, so fetch logs deliberately never store URLs, headers or exception bodies. Error reports are sanitized. Never share `.env`, database files or runtime logs containing personal data.
- Requests use TLS verification and fixed provider hosts. No user-supplied fetch URL is accepted. Upstream errors produce honest unavailable/stale results. Cached stale data keeps its original timestamp and cannot trigger alerts.
- HTTP security headers include `nosniff`, frame denial, referrer policy and API `no-store`. An operator adding a Content-Security-Policy must allow MapLibre workers (`blob:`), same-origin API/WebSockets and selected NASA imagery. Do not deploy an untested overly broad CSP.
- Dependency versions and lockfiles are included. See `VERIFICATION.md` for the audits actually executed. An audit is evidence at a point in time, not a guarantee of zero future vulnerabilities.

## Backup / restore

For SQLite, a consistent online backup is supported:

```bash
.venv/bin/python scripts/backup.py backup /safe/path/earthvision-backup.db
```

To restore, stop the server, safely move the existing `earthvision.db` and any `-wal`/`-shm` files out of the way, then:

```bash
.venv/bin/python scripts/backup.py restore /safe/path/earthvision-backup.db
```

The script refuses to overwrite an existing target and runs `PRAGMA integrity_check`. Backups contain account and preference data; keep them private. For MySQL use `mysqldump`/`mysql` with a least-privilege backup account, read credentials from protected option files or environment, and test restoration to a separate database. Never publish credentials in command arguments or documentation.

## Operation

The local server binds loopback by default. Do not expose the development server publicly. Public deployment requires HTTPS, exact allowed origins, secure cookies, a persistent private database, protected backups and review of provider terms. No password reset/email verification/email delivery service is supplied; this is a local/academic account system. Delete an installation's database only after backing it up and understanding that all accounts will be removed.
