# Public data sources, access and attribution

Documentation reviewed on 2026-11-05. Provider policies can change; no service guarantees or unlimited free quotas are promised. `provider-verification.json` records the independent HTTP probes actually executed. Adapter contract tests are separate evidence and do not establish live provider availability.

| Provider | Endpoint / docs | Access and limits | Product / usage |
|---|---|---|---|
| Open-Meteo | `api.open-meteo.com/v1/forecast`; [docs](https://open-meteo.com/en/docs), [terms](https://open-meteo.com/en/terms) | No key for non-commercial free API; 600/min, 5,000/hour, 10,000/day; larger requests may count multiple calls | Model current/hourly/daily forecasts. CC BY 4.0 data, attribute Open-Meteo. No commercial free-API claim. |
| Open-Meteo archive | `archive-api.open-meteo.com/v1/archive`; [archive docs](https://open-meteo.com/en/docs/historical-weather-api) | No key; same fair-use restrictions. App limits ranges to five years and ends at least five days ago | Historical reanalysis, not direct station observations. |
| Open-Meteo geocoder | `geocoding-api.open-meteo.com/v1/search`; [docs](https://open-meteo.com/en/docs/geocoding-api) | Public non-commercial endpoint; cache for one day | City and country search from GeoNames. |
| NASA GIBS | `gibs.earthdata.nasa.gov/wmts/epsg3857/best`; [API documentation](https://nasa-gibs.github.io/gibs-api-docs/) | No paid key for selected public layers. No numerical quota assumed; load only visible tiles, no bulk downloading | Terra/Aqua MODIS corrected-reflectance true color; `GoogleMapsCompatible_Level9`. Credit NASA GIBS/MODIS. Imagery gaps, date-specific coverage and processing delays are possible. |
| USGS | `earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_day.geojson`; [GeoJSON docs](https://earthquake.usgs.gov/earthquakes/feed/v1.0/geojson.php) | Public, no key; app caches 5 minutes rather than polling every browser repaint | Preliminary/revised event observations: magnitude, depth, event/update times, source URL. Credit USGS. |
| NASA FIRMS | `/api/area/csv/{MAP_KEY}/VIIRS_NOAA20_NRT/{bbox}/1`; [API](https://firms.modaps.eosdis.nasa.gov/api/area/), [free key](https://firms.modaps.eosdis.nasa.gov/api/map_key/) | Free email-issued MAP_KEY, kept backend-only. Standard transaction budget documented by FIRMS is 5,000 per 10 minutes; actual account limits prevail. Cache 30 minutes and small bounding boxes | Satellite hotspot detections; confidence is the source category (e.g. l/n/h), not an invented percentage. FRP in MW. Not a confirmed fire perimeter or official evacuation warning. |
| OpenAQ v3 | `api.openaq.org/v3/locations`, `/locations/{id}/latest`, `/sensors/{id}/days`; [docs](https://docs.openaq.org/), [limits](https://docs.openaq.org/using-the-api/rate-limits) | Free API key, `X-API-Key` header. Published standard limits 60/minute and 2,000/hour. Query up to five stations in a 25 km radius, cache one hour | Station observations. Join latest measurements to sensors to recover pollutant and units. Preserve station/provider metadata; underlying licenses vary. No fabricated AQI. |
| CAMS via Open-Meteo | `air-quality-api.open-meteo.com/v1/air-quality`; [docs](https://open-meteo.com/en/docs/air-quality-api) | Public non-commercial endpoint; no paid key. Cache one hour | Explicitly separate model concentrations/forecasts. Credit CAMS ENSEMBLE and Open-Meteo. Never called OpenAQ station data. |
| GDACS | `www.gdacs.org/gdacsapi/api/events/geteventlist/MAP`; [Swagger](https://www.gdacs.org/gdacsapi/swagger/index.html), [quickstart](https://www.gdacs.org/Documents/2025/GDACS_API_quickstart_v2.pdf) | Public feed without key; app caches 15 minutes. No guaranteed numerical allowance assumed | Third-party disaster alerts, including supported floods, cyclones/storms, earthquakes and other feed events. Credit GDACS, European Commission and United Nations. Severity mapping: Green 1, Orange 2, Red 3. |

## Animated radar (added in the continuation)

RainViewer [Weather Maps API](https://www.rainviewer.com/api/weather-maps-api.html) and [transition limits](https://www.rainviewer.com/api/transition-faq.html) were reviewed as documentation only; no live endpoint probe was made. The adapter targets `https://api.rainviewer.com/public/weather-maps.json` and accepts only `https://tilecache.rainviewer.com` as the returned tile host. Free historical radar frames use 512-pixel tiles, maximum zoom 7, color scheme 2. Only past frames are read; paid/removed nowcasts are ignored. Credit RainViewer visibly. Coverage, allowed usage and limits may change; no numerical rate allowance is assumed. Metadata is cached for ten minutes; the application never bulk-downloads radar tiles.

**Verification: PENDING.** Both radar hosts must be added separately to the restricted allowlist before live testing. Test-only parser/playback fixtures establish local code behavior, not real radar availability.

## Bundled assets

- **Country boundaries:** Natural Earth geometry distributed through [datasets/geo-countries](https://github.com/datasets/geo-countries). Public domain. Downloaded from `https://raw.githubusercontent.com/datasets/geo-countries/master/data/countries.geojson`, simplified for rendering and bundled in `frontend/public/countries.geojson`. Boundaries are cartographic data, not political endorsements. MapLibre performs real interactive rendering; no map screenshot substitutes for the map.
- **Seattle weather:** [Vega datasets](https://github.com/vega/vega-datasets/blob/main/data/seattle-weather.csv), daily weather 2012–2015, from NOAA as described by Vega. See `ml/data/PROVENANCE.md`. This data is deliberately historical and used only for reproducible evaluation.
- **OpenStreetMap tiles:** an optional provider probe checks `tile.openstreetmap.org`; the default application does not request these tiles because it uses bundled boundaries. If enabling OSM yourself, follow its [tile usage policy](https://operations.osmfoundation.org/policies/tiles/), including visible attribution and caching. No offline bulk tile download is included.

## Restricted network operation

Allow only the provider hosts you intend to use. Run:

```bash
.venv/bin/python scripts/verify_providers.py
```

The script reports each endpoint independently, including HTTP status, schema/content-type success, or a sanitized network/key error. A proxy rejection is recorded separately from a provider HTTP response. Missing free keys are marked untested. No key appears in the report. A failed adapter returns an explicit unavailable state and supplies no live values. `PROVIDER_NETWORK_ENABLED=false` disables external provider fetches during local-only QA.

No unrestricted egress, proxy bypass, paid endpoint, or synthetic live-data fallback is needed. NASA imagery is browser-fetched; the browser also needs access to its domain. Source success at one moment does not establish future availability.
