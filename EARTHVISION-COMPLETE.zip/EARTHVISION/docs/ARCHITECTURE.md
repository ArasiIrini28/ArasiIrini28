# Architecture

```
Browser (React + TypeScript + MapLibre + ECharts)
  | same-origin REST + HttpOnly cookie; WebSocket unread counts
FastAPI (validation, rate limits, origin checks, auth, API documentation)
  |-- provider adapters --> public environmental APIs (HTTPS)
  |-- SQLAlchemy --> SQLite locally / MySQL 8.4 in optional full stack
  |-- scikit-learn --> real chronological evaluation / anomaly detection
  |-- reports --> attributed CSV / PDF
  |-- 15-minute async scheduler --> collection and subscription evaluation
Optional: Nginx --> FastAPI; Redis --> Celery worker + one beat scheduler
```

## Independent creation and budget

All application code was created in the new `EARTHVISION` directory. The only downloaded non-package assets are public Natural Earth country geometries and a real historical Seattle weather dataset. No prior EarthVision implementation, STEMQuest code or unrelated workspace project was imported or edited.

SQLite is the default because it requires no service, cloud account or payment details and lowers memory requirements. MySQL 8.4 is a supported MySQL 8 LTS option for the full local stack. Redis and Celery are optional local processes, not paid managed services. There is one background scheduler per deployment: either the built-in local loop or Celery Beat, never both. No PyTorch or XGBoost is needed for this small tabular task; simpler evaluated models are sufficient.

## Relational design

`data_sources` is referenced by measurements, event records and satellite metadata. `locations` is deduplicated by rounded (4 decimal places) latitude/longitude. `saved_locations` joins users to locations without duplicating the geographical record. `weather_data` holds a unique location/source/time/product record; `rainfall_data` and `wind_data` are 1:1 child tables. `air_quality` has a unique location/source/time/parameter/sensor key.

`earthquakes`, `wildfires` and `disaster_events` use provider IDs and retain source attributes. Event revisions update the existing record. `satellite_layers` stores catalog metadata, not imaginary imagery. `users` references `user_preferences`, `sessions`, `alert_subscriptions`, `notification_logs`, and `audit_logs`. Each notification has a unique subscription/event key. `ml_models` is keyed by the input dataset fingerprint; `ml_predictions` has a unique model/target-date key. `api_fetch_logs` stores safe fetch outcomes and `provider_cache` retains response envelopes and expiration times. All tables have created timestamps and appropriate foreign keys/indexes.

Alembic revision `0001` creates the initial metadata schema. Future schema changes must use new explicit migration revisions; do not change a deployed initial migration. `database/schema-sqlite.sql` and `database/schema-mysql.sql` are generated from this version's metadata for review. Use Alembic, not direct SQL imports, for normal startup.

## Data flow and provenance

Adapters check HTTP errors and expected schemas before exposing successful data. Cache keys are hashes of provider/product/request identity, not raw authenticated URLs. Forecast cache: 15 minutes; USGS: 5 minutes; GIBS tiles: browser/provider-managed; archive: 24 hours; FIRMS: 30 minutes; air quality: 1 hour; GDACS: 15 minutes. Brief 60-second failure caching avoids retry storms. Stale records preserve the original retrieval timestamp and remain labelled stale, including on repeated reads. Stale data cannot generate new notifications.

The cached envelope distinguishes model forecasts, reanalysis, station observations, satellite detections, and third-party alerts. No fallback changes product type invisibly. Current weather and air snapshots are persisted relationally; archive/forecast time series are retained in the attributed provider cache. Reports export the same retrieved archive data. A source timestamp can be absent when a provider does not supply it; retrieval time is not represented as observation time.

Retention removes fetch logs after 30 days, audit/notification history after 90 days, current weather/air snapshots after 365 days, expired sessions, and cache entries expired for seven days. Global event history and ML evaluations remain until explicitly archived by the operator; monitor database size. Local cache/scheduler/HTTP rate limits are designed for a small single-instance portfolio installation, not a global production service.

## UI behavior

Each navigation entry renders an implemented feature. Location search supports geocoding and explicit coordinates; clicking the bundled real map also selects coordinates. Coordinate entry works without a geocoder. Country geometry is bundled, so the interactive base map works offline. Map observations are selectable point values, not interpolated worldwide meteorological fields. Event markers use returned coordinates and expose source details. Satellite tiles are requested from NASA only when their layer is selected and provider networking is enabled. The city page has Today, Hourly, 10-day and Radar tabs. RainViewer supplies past radar frame metadata; the map swaps real tile layers under explicit playback/timeline/opacity controls. Metadata and tiles are not requested in the delivered network-disabled configuration.

Loading, unavailable, stale, missing-key and empty-feed states are separate. User text is React-escaped; popup content uses `setText`, not HTML. External links allow HTTPS only. MapLibre's native controls provide zoom/pan. ECharts supports tooltips and chart legends. CSV/PDF exports are downloadable backend responses.

## ML and evaluation

See `ml/MODEL_CARD.md`. Predictors use only information available through day t to predict maximum temperature on t+1. A 70/15/15 chronological split prevents random temporal leakage. Ridge standardization fits on the training partition only. Model selection uses validation MAE. The selected model is evaluated on the untouched test period, alongside persistence. Refit on all known observations happens only after that held-out evaluation. Evaluation JSON includes target date, split dates/counts, metrics and actual/predicted test pairs. Reanalysis is not a perfect substitute for operational forecast verification.
