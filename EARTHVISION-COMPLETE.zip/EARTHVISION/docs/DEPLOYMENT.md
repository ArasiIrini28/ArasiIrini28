# Deployment with no paid resources

## Recommended: run locally on hardware you already own

`start.bat` or `bash start.sh` is the supported ₹0-software path. No cloud registration, payment method or free-tier quota is involved. The application is available only while your computer and server run. Hardware, electricity and internet connectivity are not supplied by this project.

A public website is not required for the local application to work. No hosting account was created, no subscription bought, and no chargeable resource was provisioned during development.

## Optional local Docker

Docker Engine and Docker Compose are free/open source. Docker Desktop's license depends on the user's organization; check eligibility rather than assuming every business use is free. On Linux, Docker Engine avoids that uncertainty.

```bash
cp .env.example .env
docker compose up --build
# http://localhost:8000
docker compose down
```

The SQLite database is in a named volume. Do not use `down -v` unless you deliberately intend to erase it. The container runs as a non-root user. Image/package downloads take time and disk space. Budget about 2 GB RAM for the default local stack; the full stack benefits from 4 GB or more. Actual usage varies.

## Full local stack: MySQL 8.4, Redis, Celery, Nginx

Add these **local credentials** to `.env` yourself. Use different long randomly generated URL-safe passwords; no password is shipped:

```dotenv
MYSQL_PASSWORD=your-own-random-url-safe-password
MYSQL_ROOT_PASSWORD=a-different-random-url-safe-password
```

Then:

```bash
docker compose --env-file .env -f infrastructure/compose.full.yml up --build
# http://localhost:8080
docker compose --env-file .env -f infrastructure/compose.full.yml down
```

The application waits for database health and runs Alembic migrations. Worker/Beat wait for the application's health check. Only one Beat runs. The built-in scheduler is disabled in this configuration. MySQL and Redis are private to the Docker network. Nginx exposes loopback port 8080. For unusual password characters, percent-encode the database URL rather than placing raw reserved characters in a URL; URL-safe generated values avoid this issue.

## Optional free public demo hosting

A permanent public backend with private durable storage is **not guaranteed at ₹0** by any host. Do not enter payment details or enable billing to follow this guide. If no suitable no-card free plan is available, continue using the complete local version.

A possible limited demo option is a **free CPU Docker Space on Hugging Face**, only if its current no-card terms are acceptable at signup. No account is created by these scripts. Select free CPU hardware only; never enable a paid upgrade or persistent-storage add-on. Adapt the Dockerfile's server port to `7860` and configure the platform's app port; set exact `ALLOWED_ORIGINS` and `COOKIE_SECURE=true`. Upload source without `.env`, local databases or test accounts. Set optional free API keys using platform secrets.

**Critical limitations:** free Spaces can sleep, rebuild, have limited CPU/RAM/bandwidth, and lose writable-container data across restarts. Background alerts stop while asleep. Therefore this is only a disposable public demonstration, not durable account hosting. Keep durable personal use local. Review outbound-network restrictions and Open-Meteo non-commercial terms. The deployed demo must visibly explain persistence limitations before accepting important user data.

Static-only hosts can serve a frontend build but **cannot replace the Python API, SQL database, accounts, exports or ML training**. Do not present a static deploy as the complete application. No guaranteed free always-on MySQL/Redis service is assumed. This repository deliberately contains no scripts that allocate cloud resources or silently upgrade a plan.

## Managed build environments with an HTTPS proxy

The Dockerfile supports an optional BuildKit `proxy_ca` secret. For this development environment, use the supplied public CA bundle, not disabled TLS validation:

```bash
docker build --secret id=proxy_ca,src=/etc/ssl/certs/ca-certificates.crt -f infrastructure/Dockerfile -t earthvision:local .
```

Outside such an environment, `docker compose up --build` needs no custom secret. Do not bake session proxies, certificates or credentials into distributed images.
