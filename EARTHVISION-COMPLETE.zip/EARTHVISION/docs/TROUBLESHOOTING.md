# Troubleshooting

| Symptom | Resolution |
|---|---|
| Python/Node command missing | Install Python 3.12+ and Node.js 24 LTS with PATH integration; reopen the terminal. On Windows prefer `py -3 scripts\start.py`. |
| Install cannot reach PyPI/npm | Check permitted package hosts and inherited proxy/CA configuration. Keep TLS verification enabled. No dependency download is replaced with a fake package. |
| Port 8000 already used | Stop the process you own, or start Uvicorn with `--port 8001` and add the exact URL to `ALLOWED_ORIGINS`. Do not kill unrelated projects. |
| Website says build frontend | Run `npm ci` then `npm run build` in `frontend/`, and restart FastAPI. |
| Provider unavailable / verification pending | Inspect the source status, `PROVIDER_NETWORK_ENABLED`, network allowlist and `docs/provider-verification.json`. Run `scripts/verify_providers.py` after allowing documented hosts. |
| Missing FIRMS/OpenAQ key | Obtain the optional free key from the official source, put it in backend `.env`, restart. Weather, country map and historical benchmark do not need those keys. |
| Geocoder is unavailable | Enter `latitude, longitude` in search or click the interactive map. Those actions require no geocoding API. |
| Radar playback is disabled | Provider networking is deliberately disabled by default pending allowlist confirmation. Radar needs `api.rainviewer.com` and `tilecache.rainviewer.com`. No frames means no playback; no model rainfall is mislabelled radar. |
| Empty GIBS tiles | Choose an earlier date (e.g. three days ago), check the satellite's operating period, and allow NASA GIBS in the browser network. Empty tiles are not evidence of clear weather. |
| Map cannot render WebGL | Enable hardware acceleration/WebGL or use a browser supporting WebGL2. Coordinate search and all data pages still work. No decorative screenshot is substituted. |
| Archive dates rejected | End at least five days ago, start before end, use at most five years. |
| Training rejected | Request at least 180 consecutive daily records. Missing data are not silently invented. Historical prediction dates follow the dataset, not today's date. |
| Login works locally but fails behind HTTPS | Set `COOKIE_SECURE=true` and exact `ALLOWED_ORIGINS`; do not mix hostnames or HTTP/HTTPS. |
| API returns 429 | Wait 60 seconds. Provider caches and limited parallel requests protect free quotas. Development tests use a higher rate limit on an isolated test database. |
| Alerts don't arrive | Server must run; verify subscription thresholds/radius and source availability. No new notification is created from stale/failed data. Use Check now to inspect unavailable counts. |
| Database locked | Default SQLite is for one application instance. Stop duplicate servers/schedulers; use the optional MySQL stack for multiple processes. Back up before changing databases. |
| Docker cannot start | Verify Docker Engine is running and your user has access. Do not replace unrelated containers or escalate to paid hosted services. |
| Windows dependencies fail | Use 64-bit Python 3.12/3.13 and Node 24 LTS; avoid running from a very long or protected path. |

The application's errors never include provider secrets. For an upstream outage, cached data are explicitly stale; when no cache exists, values remain unavailable. Retries must not bypass provider or environment access controls.
