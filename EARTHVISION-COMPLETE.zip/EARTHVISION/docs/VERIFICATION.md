# EarthVision verification report

**Delivery status: local build verified; live-provider verification PENDING.**

The user explicitly instructed that provider domains have not yet been confirmed on the restricted allowlist. No external provider smoke probes were run during final verification. The delivery defaults to `PROVIDER_NETWORK_ENABLED=false`. Missing environmental values remain unavailable; no fabricated live data is supplied.

## Executed checks

| Check | Executed result |
|---|---|
| Frontend `npm run build` | PASS — TypeScript and Vite production build, including separately bundled MapLibre worker |
| Frontend `npm run lint` | PASS — TypeScript and ESLint |
| Backend/scripts Ruff | PASS |
| Backend `python -m pytest -q` | **41 passed** — API/auth, database deduplication, ownership, sessions, alert rules/read state, WebSocket count, CSV/PDF, provider contracts/failures, ten-day request, radar metadata validation, real ML evaluation/leakage |
| Frontend `npm test` | **11 passed** — source/empty/error states, safe links, city tabs and isolated radar play/pause/scrub controls |
| Chromium Playwright workflows | **6 passed** — all navigation, register/login/logout, saved locations, preferences, alerts, loaded country geometry, map controls, mobile layout, real historical ML view, hourly/10-day/radar views |
| Real-data ML evaluation | Executed on 1,461 Seattle daily records; 1,453 supervised rows, chronological 1,017/218/218 split |
| npm dependency audit | **0 known vulnerabilities** in the resolved dependency tree at audit time |
| Python dependency audit | **0 known vulnerabilities** in the development virtual environment at audit time |
| SQLite backup and restore | Both executed on disposable QA data; integrity checks passed |
| Default Docker image | Successfully built from the supplied multi-stage Dockerfile; non-root server started and database health passed |
| Default/full Compose config | Both parsed/validated; no cloud resources created |
| Docker application smoke | **16 local checks passed**, including accounts, preferences, saved locations, alerts, map asset, real ML and explicitly pending provider states |
| Clean ZIP-extracted application | Started on a separate local port with a fresh database; the same **16 local checks passed** |
| ZIP integrity | CRC checked, every archived file checked against SHA-256 manifest, safe relative paths checked, runtime databases/keys/caches excluded |

A non-failing Starlette deprecation warning says its TestClient will prefer `httpx2` in a future version. Current `httpx` tests executed successfully. Audits are point-in-time package evidence; OS/container image layers were not independently vulnerability-scanned.

## Model results actually measured

Reference source: real Seattle weather, 2012–2015, via Vega/NOAA. Selected by validation MAE: **Ridge**.

| Held-out test model | MAE °C | RMSE °C | R² |
|---|---:|---:|---:|
| Ridge | 2.1010 | 2.6514 | 0.8936 |
| Persistence | 2.2514 | 2.9302 | 0.8701 |

Held-out targets: 2015-05-28 through 2015-12-31. The refitted estimate is 5.71°C maximum for **2016-01-01**, clearly historical. It is not a present-day live prediction or evidence of global accuracy. Exact splits, scores and test predictions are in `ml/evaluation.json`; provenance and limits are in `ml/MODEL_CARD.md`.

## Fixes made during real testing

- Corrected accessible labels discovered in the registration/preferences workflow.
- Updated vulnerable package versions; resolved the remaining development minimatch advisory through a pinned override and reran lint/build/tests.
- Fixed the MapLibre 6 worker bundle path and invalid simplified polygon rings. Visual inspection revealed the worker defect; the strengthened browser test now verifies country selection and absence of a source-load warning.
- Preserved stale status across repeated cache reads; stale data never triggers new notifications.
- Reduced Docker layers after the environment's disk limit was reached. Removed only EarthVision-owned build artifacts.
- Fixed container source permissions so the non-root runtime can import application code.
- Added explicit offline gating, ten-day forecast contracts and tested historical-radar playback controls during continuation.

## External status — all PENDING

Open-Meteo forecast/archive/geocoding/CAMS, NASA GIBS, USGS, NASA FIRMS, OpenAQ and GDACS are implemented but not live-verified in this environment. FIRMS and OpenAQ also require free backend keys. RainViewer metadata and tile integration is implemented and locally contract-tested, but requires two extra allowlisted hosts: `api.rainviewer.com` and `tilecache.rainviewer.com`. OSM tile access is also unverified; the actual base map uses bundled public-domain country geometry and does not need OSM tiles.

`docs/provider-verification.json` records each pending host with `http_status: null`. Do not interpret contract fixtures as upstream verification. No fixture is accessible from production provider routes. Only after the user's confirmation should `scripts/verify_providers.py` run and record actual HTTP/schema outcomes.

## Other limits

- The optional full MySQL 8.4/Redis/Celery/Nginx stack has configuration validation and a generated MySQL schema, but was **not run end-to-end**. SQLite and the default Docker runtime were actually run.
- Windows startup files and instructions are provided; a Windows host was unavailable, so Windows execution is **not claimed**.
- No public hosting was created or verified. The complete local version is the supported ₹0 baseline.
- Satellite/radar tile rendering from real remote sources, live-location training and live-source exports await the restricted-network verification stage. Local control logic, contracts and unavailable states were tested.

## Evidence and reproducibility

`docs/evidence/` contains backend JUnit output, backend/component test summaries, Playwright results, npm/Python audit JSON, Docker smoke results and extracted-copy smoke results. The ZIP includes `MANIFEST.sha256`; its adjacent `.zip.sha256` file checks the entire archive. The final archive's runtime/source hashes are compared with the independently smoke-tested extracted copy; delivery-only report additions do not change application behavior.

**Next task:** obtain restricted allowlist confirmation, test each provider independently, retain explicit errors for failures, configure optional free keys where desired, test successful integrations through the UI and update the report/ZIP. Budget remains ₹0.
