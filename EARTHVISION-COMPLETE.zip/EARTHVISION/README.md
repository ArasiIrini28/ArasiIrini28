# EarthVision — Global Weather & Earth Intelligence

**Explore Earth. Monitor Weather. Understand Our Planet.**

A new, independent local application built with React/TypeScript/Vite, MapLibre, ECharts, FastAPI, SQLAlchemy and scikit-learn. No previous EarthVision or other project source is used. There are no paid APIs, subscriptions or cloud provisioning scripts.

## Quick start (₹0 software)

Install **Python 3.12+** and **Node.js 24 LTS**, both free. Extract the ZIP, open the `EARTHVISION` folder, and:

- **Windows:** double-click `start.bat`, or run `py -3 scripts\start.py` in PowerShell.
- **macOS/Linux:** run `bash start.sh` (or `python3 scripts/start.py`).

The launcher creates `.venv`, installs the exact locked dependencies, copies `.env.example` to `.env` if absent, builds the website, applies database migrations and starts the server.

Open **http://localhost:8000**. API documentation: **http://localhost:8000/docs**.
Stop with **Ctrl+C** in the terminal. SQLite data persists in `earthvision.db`. You can register your own account; no default account or password is shipped. Startup requires internet to install dependencies. After installation, the application, bundled map and historical ML benchmark run locally; current external data still requires internet.

## Configuration

**Live-provider verification is PENDING.** This delivery defaults to `PROVIDER_NETWORK_ENABLED=false`, as requested. Local accounts, database, country map, and the real historical ML benchmark work without provider access. After the restricted allowlist is confirmed, run the documented independent provider checks and set `PROVIDER_NETWORK_ENABLED=true` in `.env` to enable external data requests. No missing live values are fabricated.

Core forecasts, archive, geocoding, CAMS model air quality, USGS, GDACS and NASA GIBS use public endpoints without a paid key. Data availability is determined by actual successful requests; failures are visible, never replaced with fake live data.

Optional, free keys are configured **only in `.env`**:

```dotenv
FIRMS_MAP_KEY=
OPENAQ_API_KEY=
```

FIRMS signup: https://firms.modaps.eosdis.nasa.gov/api/map_key/  
OpenAQ signup and API documentation: https://docs.openaq.org/using-the-api/api-key

Do not put keys in the frontend, Git, screenshots or chat. Restart after editing `.env`. OpenAQ station observations and NASA FIRMS detections remain explicitly unavailable without their keys. The CAMS tab is separately labelled **model forecast**, never a disguised OpenAQ fallback.

Open-Meteo's free endpoint is for **non-commercial use**. This project targets academic/portfolio use. See [provider terms and limits](docs/DATA_SOURCES.md).

## What is implemented

- Thirteen responsive pages, dark/light themes, global city search and coordinate entry.
- Real MapLibre pan/zoom/click interaction; bundled Natural Earth boundaries; selectable weather point layers, event markers and dated NASA GIBS imagery.
- City weather pages with Today, Hourly, 10-day and animated Radar views; archive analysis and location comparisons; temperature, rainfall and wind charts.
- RainViewer historical radar integration with play/pause, timeline, step controls, speed and opacity; external tiles remain unverified.
- USGS earthquakes, FIRMS satellite hotspots, GDACS disasters, CAMS air quality and optional OpenAQ station measurements/history.
- Source, product type, retrieval time, source timestamps, cache/stale/error status; no invented observations.
- Argon2id passwords, opaque expiring server sessions in HttpOnly cookies, ownership checks, saved places and preferences.
- Threshold subscriptions, geographic radius filtering, deduplicated notifications, read/unread history and WebSocket unread counts.
- Real-data chronological ML evaluation (persistence/Ridge/Random Forest), historical next-day temperature prediction, Isolation Forest anomalies and linear trends.
- CSV and PDF exports containing source attribution, timestamps and the retrieved real data.
- SQLite quick start; optional local MySQL 8.4 / Redis / Celery / Nginx stack; migrations and backup tooling.

### Scope and honest limitations

Radar uses free past observations (typically two hours), not paid nowcasts. It needs `api.rainviewer.com` and `tilecache.rainviewer.com` in addition to the original provider hosts. Playback is disabled when no real frames are available. The city layout is inspired by familiar weather-service information hierarchy; no Weather.com data, assets or paid API are used.

Weather map layers show actual model **point samples at inspected locations**, not a manufactured continuous global raster. FIRMS shows the last day's hotspots in a 10° box around the selected point. USGS uses its past-day feed. GDACS coverage is whatever its map feed returns. GIBS availability varies by date, satellite and tile. Air-quality coverage is not uniform.

The bundled ML benchmark uses **real Seattle daily weather, 2012–2015**. Its next-day target is **2016-01-01**, deliberately labelled historical. A signed-in user can train a new location model from at least 180 consecutive archive days. Forecast skill in Seattle does not establish skill elsewhere. Automated summaries are deterministic, data-grounded interpretations; there is no paid LLM.

Alerts are third-party/model-derived in-app notifications, **not emergency warnings**. The server must be running. There is no email/SMS service. A single local scheduler checks every 15 minutes; optional Celery replaces it. Reports and charts retain explicitly displayed source units even when dashboard cards use imperial preferences.

## Development and tests

```bash
# From EARTHVISION after the first startup:
.venv/bin/python -m pytest -q
.venv/bin/python -m ruff check backend ml workers tests scripts
.venv/bin/python -m ml.pipeline
cd frontend
npm run lint
npm test
npm run build
```

On Windows, use `.venv\Scripts\python.exe` instead. `scripts/test.sh` runs backend tests, lint, frontend tests and build on macOS/Linux.

Browser workflow tests need the application running on port 8000 and a browser:

```bash
cd frontend
npx playwright install chromium
npm run test:e2e
```

Alternatively set `CHROMIUM_PATH` to an already installed Chromium executable. Tests create isolated test accounts; do not run browser tests against a production user database. Use a temporary `DATABASE_URL` and `SCHEDULER_ENABLED=false`. Backend contract-test fixtures are test-only and are never loaded by the runtime.

For development, run the backend with `.venv/bin/python -m uvicorn backend.app.main:app --reload --port 8000` and `npm run dev` in `frontend/`. Visit http://localhost:5173. Built production files are served by FastAPI on port 8000.

## Docker (optional, local only)

Copy `.env.example` to `.env`, then run `docker compose up --build`. Open http://localhost:8000; stop with `docker compose down`. Volumes preserve data. Do not add `-v` unless you intend to delete the database.

The optional full local stack and free deployment options are documented in [DEPLOYMENT.md](docs/DEPLOYMENT.md). No cloud resources are automatically created.

## Project map

| Directory | Purpose |
|---|---|
| `frontend/` | React application, MapLibre map, ECharts charts, component/browser tests |
| `backend/app/` | FastAPI, authentication, adapters, persistence, alert rules |
| `database/` | Alembic migration and generated SQL schema |
| `ml/` | Real reference dataset, provenance, training/evaluation/anomaly pipeline |
| `workers/` | Celery scheduled collection and retention |
| `infrastructure/` | Dockerfile, optional full Compose stack, Nginx |
| `tests/` | Backend/API/database/provider/security/ML tests |
| `scripts/` | Startup, tests, backup and provider verification |
| `docs/` | Architecture, sources, security, testing evidence, deployment and troubleshooting |

See [VERIFICATION.md](docs/VERIFICATION.md) for **checks actually executed and remaining verification limits**, [PROGRESS.md](docs/PROGRESS.md) for the development record, and [SECURITY.md](docs/SECURITY.md) for the local security model. Code is MIT licensed; third-party data and packages retain their own licenses.
