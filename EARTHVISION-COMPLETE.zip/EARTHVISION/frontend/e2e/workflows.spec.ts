import {test,expect} from '@playwright/test';

test('all navigation pages render without runtime errors',async({page})=>{
 const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto('/');await expect(page.getByRole('heading',{name:'A clearer view of our planet.'})).toBeVisible();
 for(const id of ['map','weather','satellite','earthquakes','wildfires','air-quality','disasters','ml','analytics','alerts','profile','about']){
  await page.locator('nav a[href="#'+id+'"]').click();await expect(page.locator('main h1')).toBeVisible();
  await expect(page.getByText('EarthVision encountered a display error.')).toHaveCount(0);
 }
 expect(errors).toEqual([]);
});
test('register, save location, preferences, alerts, logout and login',async({page})=>{
 const email=`e2e-${Date.now()}@example.org`;
 await page.goto('/#profile');await page.getByRole('button',{name:'New to EarthVision? Create an account'}).click();
 await page.getByLabel('Your name').fill('Test Explorer');await page.getByLabel('Email',{exact:true}).fill(email);await page.getByLabel('Password',{exact:true}).fill('Browser-password-284!');await page.getByRole('button',{name:'Create account',exact:true}).click();
 await expect(page.getByRole('heading',{name:'Hello, Test Explorer'})).toBeVisible();
 await page.getByLabel('Theme',{exact:true}).selectOption('light');await page.getByLabel('Dashboard units').selectOption('imperial');await page.getByLabel('Home page').selectOption('weather');await page.getByRole('button',{name:'Save preferences'}).click();
 await page.locator('nav a[href="#weather"]').click();await page.getByLabel('Search locations').fill('51.5, -0.12');await page.getByRole('button',{name:'Search',exact:true}).click();await expect(page.locator('.current-place')).toContainText('51.500');await page.getByRole('button',{name:'Save selected location',exact:true}).click();
 await page.locator('nav a[href="#profile"]').click();await expect(page.getByRole('button',{name:'Explore',exact:true})).toBeVisible();
 await page.locator('nav a[href="#alerts"]').click();await page.getByRole('button',{name:'Create subscription'}).click();await expect(page.locator('.subscription')).toContainText('temperature');await page.getByRole('button',{name:'Check now'}).click();await expect(page.getByRole('status')).toContainText('subscriptions checked');await page.getByRole('button',{name:'Delete temperature alert'}).click();await expect(page.locator('.subscription')).toHaveCount(0);
 await page.locator('nav a[href="#profile"]').click();await page.getByRole('button',{name:'Sign out'}).click();await page.getByLabel('Email',{exact:true}).fill(email);await page.getByLabel('Password',{exact:true}).fill('Browser-password-284!');await page.getByRole('button',{name:'Sign in',exact:true}).click();await expect(page.getByRole('heading',{name:'Hello, Test Explorer'})).toBeVisible();await expect(page.getByLabel('Dashboard units')).toHaveValue('imperial');
});
test('interactive map renders WebGL and changes selected coordinates',async({page})=>{
 await page.goto('/#map');const canvas=page.locator('.maplibregl-canvas');await expect(canvas).toBeVisible();await page.waitForTimeout(1500);await expect(page.locator('.map-warning')).toHaveCount(0);
 const before=await page.locator('.current-place').innerText();const box=await canvas.boundingBox();await canvas.click({position:{x:box!.width/2,y:box!.height/2}});await expect(page.locator('.current-place')).not.toHaveText(before);await expect(page.locator('.current-place strong')).toHaveText('India');
 await page.getByLabel('Weather map layer').selectOption('precipitation');await expect(page.getByLabel('Weather map layer')).toHaveValue('precipitation');
 await page.getByRole('button',{name:'Zoom in'}).click();await page.getByRole('button',{name:'Reset global map view'}).click();
});
test('historical benchmark displays actual evaluation',async({page})=>{
 await page.goto('/#ml');await expect(page.getByText('2016-01-01',{exact:true})).toBeVisible({timeout:20000});await expect(page.locator('table').first()).toContainText('ridge');await expect(page.getByText('Chronological 70 / 15 / 15')).toBeVisible();
});
test('mobile navigation and layout',async({page})=>{
 await page.setViewportSize({width:390,height:844});await page.goto('/');await page.getByRole('button',{name:'Toggle navigation'}).click();await page.locator('nav a[href="#profile"]').click();await expect(page.getByRole('heading',{name:'Welcome back, explorer.'})).toBeVisible();
 const overflow=await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth);expect(overflow).toBe(false);
});

test('city weather tabs expose 10-day, hourly and honest radar states',async({page})=>{
 await page.goto('/#weather');await expect(page.locator('.city-hero h2')).toContainText('New Delhi');
 await page.getByRole('tab',{name:'10-day forecast'}).click();await expect(page.getByRole('heading',{name:'10-day weather forecast'})).toBeVisible();
 await page.getByRole('tab',{name:'Hourly'}).click();await expect(page.getByRole('heading',{name:'Hourly weather · next 48 hours'})).toBeVisible();
 await page.getByRole('tab',{name:'Weather radar'}).click();await expect(page.getByRole('heading',{name:'Animated weather radar'})).toBeVisible();await expect(page.getByRole('button',{name:'Play radar animation'})).toBeDisabled();
});
