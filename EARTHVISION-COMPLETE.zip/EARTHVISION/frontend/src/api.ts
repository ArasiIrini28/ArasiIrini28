import {useEffect, useState} from 'react';
export type Place = {name:string;latitude:number;longitude:number};
export type Envelope = {provider:string;kind:string;status:string;available:boolean;fetched_at:string;source_time?:string;message?:string;attribution:string;data:any;total?:number;trends?:any};
export async function api<T=any>(url:string, method='GET', body?:unknown):Promise<T>{
  const response=await fetch('/api'+url,{method,credentials:'same-origin',headers:body===undefined?{}:{'Content-Type':'application/json'},body:body===undefined?undefined:JSON.stringify(body)});
  const data=await response.json();
  if(!response.ok) throw new Error(typeof data.detail==='string'?data.detail:JSON.stringify(data.detail??'Request failed'));
  return data;
}
export function useData<T=any>(url:string|null, revision=0){
  const [data,setData]=useState<T|null>(null),[error,setError]=useState(''),[loading,setLoading]=useState(false);
  useEffect(()=>{let active=true;setData(null);setError('');if(!url){setLoading(false);return;} setLoading(true);
    api<T>(url).then(value=>{if(active)setData(value)}).catch(e=>{if(active)setError(e.message)}).finally(()=>{if(active)setLoading(false)});
    return()=>{active=false};
  },[url,revision]);
  return {data,error,loading};
}
export const query=(p:Place)=>`latitude=${p.latitude}&longitude=${p.longitude}`;
export const display=(value:unknown,digits=1)=>typeof value==='number'?value.toLocaleString(undefined,{maximumFractionDigits:digits}):'—';
export const timestamp=(value:unknown)=>value?new Date(typeof value==='number'?value:String(value).match(/Z$|[+-]\d\d:\d\d$/)?String(value):String(value)+'Z').toLocaleString():'Not supplied';
export const safeUrl=(value:unknown)=>typeof value==='string'&&/^https:\/\//i.test(value)?value:undefined;
