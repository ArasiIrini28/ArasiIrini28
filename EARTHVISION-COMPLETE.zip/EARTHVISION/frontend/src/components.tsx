import {useEffect,useRef} from 'react';
import {AlertCircle,ArrowUpRight,LoaderCircle} from 'lucide-react';
import type {Envelope} from './api';
import {display,timestamp} from './api';
export function Loading(){return <div className="empty" role="status"><LoaderCircle className="spin" size={22}/> Retrieving source data…</div>}
export function ErrorBox({message}:{message:string}){return <div className="notice error" role="alert"><AlertCircle size={18}/>{message}</div>}
export function SourceStatus({data}:{data:Envelope|null}){if(!data)return null;return <div className={'source-status '+(data.available?'':'unavailable')}><span className="status-dot"/><strong>{data.provider}</strong><span>{data.kind}</span><span className="tag">{data.status}</span><span>{data.available?'Fetched':'Checked'} {timestamp(data.fetched_at)}</span>{data.source_time&&<span>Source time {timestamp(data.source_time)}</span>}{data.message&&<p>{data.message}</p>}</div>}
export function Empty({children}:{children:React.ReactNode}){return <div className="empty"><AlertCircle size={22}/><div>{children}</div></div>}
export function Metric({label,value,unit,icon,detail}:{label:string;value:unknown;unit:string;icon:React.ReactNode;detail?:string}){return <article className="metric"><div className="metric-top">{label}<span>{icon}</span></div><div className="metric-value">{typeof value==='string'?value:display(value)}<small>{unit}</small></div><div className="muted text-xs">{detail??'Selected location · model forecast'}</div></article>}
export function SectionHead({eyebrow,title,action}:{eyebrow?:string;title:string;action?:React.ReactNode}){return <div className="section-head"><div>{eyebrow&&<div className="eyebrow">{eyebrow}</div>}<h2>{title}</h2></div>{action}</div>}
export function PageLink({page,children}:{page:string;children:React.ReactNode}){return <a href={'#'+page} className="text-link">{children}<ArrowUpRight size={15}/></a>}
export function Chart({labels,series,height=280}:{labels:string[];series:{name:string;data:(number|null)[];color?:string;type?:'bar'|'line'}[];height?:number}){
 const root=useRef<HTMLDivElement>(null);
 useEffect(()=>{let disposed=false;let instance:import('echarts').ECharts|undefined;let observer:ResizeObserver|undefined;
 import('echarts').then(echarts=>{if(disposed||!root.current)return;instance=echarts.init(root.current);instance.setOption({color:['#59d7a4','#62a8ef','#e9b96c'],tooltip:{trigger:'axis'},legend:{textStyle:{color:'#91a4b8'},bottom:0},grid:{top:22,left:48,right:20,bottom:56},xAxis:{type:'category',data:labels,axisLabel:{color:'#91a4b8',hideOverlap:true},axisLine:{lineStyle:{color:'#304254'}}},yAxis:{type:'value',axisLabel:{color:'#91a4b8'},splitLine:{lineStyle:{color:'#304254',opacity:.35}}},series:series.map(s=>({...s,type:s.type??'line',showSymbol:false,smooth:false,lineStyle:{width:2},areaStyle:s.type==='bar'?undefined:{opacity:.06}}))});observer=new ResizeObserver(()=>instance?.resize());observer.observe(root.current);});
 return()=>{disposed=true;observer?.disconnect();instance?.dispose()};
 },[labels,series]);
 return <div ref={root} style={{height,width:'100%'}} role="img" aria-label={series.map(s=>s.name).join(', ')+' chart'}/>;
}
