import {describe,it,expect} from 'vitest';
import {render,screen} from '@testing-library/react';
import {Empty,ErrorBox,Metric,SourceStatus} from './components';
import {display,safeUrl,timestamp} from './api';
const envelope={provider:'TEST provider',kind:'forecast',status:'unavailable',available:false,fetched_at:'2025-01-01T00:00:00Z',attribution:'TEST ONLY',message:'Source not reachable',data:null};
describe('Provenance and empty states',()=>{
 it('shows missing measurements as unavailable, never zero',()=>{render(<Metric label="Temperature" value={undefined} unit="°C" icon={<span/>}/>);expect(screen.getByText('—')).toBeInTheDocument();expect(screen.queryByText('0')).not.toBeInTheDocument()});
 it('preserves provider status and message',()=>{render(<SourceStatus data={envelope}/>);expect(screen.getByText('TEST provider')).toBeInTheDocument();expect(screen.getByText('unavailable')).toBeInTheDocument();expect(screen.getByText('Source not reachable')).toBeInTheDocument()});
 it('renders a stale badge instead of live',()=>{render(<SourceStatus data={{...envelope,status:'stale',available:true}}/>);expect(screen.getByText('stale')).toBeInTheDocument();expect(screen.queryByText('live')).not.toBeInTheDocument()});
 it('announces errors accessibly',()=>{render(<ErrorBox message="Network failure"/>);expect(screen.getByRole('alert')).toHaveTextContent('Network failure')});
 it('renders an actionable empty state',()=>{render(<Empty><a href="#profile">Sign in</a></Empty>);expect(screen.getByRole('link')).toHaveAttribute('href','#profile')});
 it('blocks unsafe external links',()=>{expect(safeUrl('javascript:alert(1)')).toBeUndefined();expect(safeUrl('http://example.org')).toBeUndefined();expect(safeUrl('https://example.org')).toBe('https://example.org')});
 it('handles null and zero without confusion',()=>{expect(display(null)).toBe('—');expect(display(0)).toBe('0');expect(timestamp(null)).toBe('Not supplied')});
});
