import {describe,it,expect,vi,afterEach} from 'vitest';
import {render,screen,fireEvent,act} from '@testing-library/react';
import CityWeather,{RadarPanel,condition} from './CityWeather';
const fixture=vi.hoisted(()=>({result:null as any}));
vi.mock('./api',async importOriginal=>({...await importOriginal<object>(),useData:()=>({data:fixture.result,loading:false,error:''})}));
vi.mock('./MapView',()=>({default:({radar}:any)=><div data-testid="radar-map" data-frame={radar?.time??''}/> }));
const place={name:'Test city',latitude:0,longitude:0};
afterEach(()=>{vi.useRealTimers();fixture.result=null});
describe('City weather and radar',()=>{
 it('exposes hourly, 10-day and radar views without invented observations',()=>{render(<CityWeather place={place} onPlace={()=>{}} result={null} loading={false} error="" units="metric"/>);fireEvent.click(screen.getByRole('tab',{name:'10-day forecast'}));expect(screen.getByText('The 10-day forecast will be displayed when Open-Meteo responds successfully.')).toBeInTheDocument();fireEvent.click(screen.getByRole('tab',{name:'Hourly'}));expect(screen.getByText('No hourly forecast has been retrieved. No substitute values are shown.')).toBeInTheDocument()});
 it('disables playback when real radar frames are unavailable',()=>{render(<RadarPanel place={place} onPlace={()=>{}}/>);expect(screen.getByRole('button',{name:'Play radar animation'})).toBeDisabled();expect(screen.getByLabelText('Radar timeline')).toBeDisabled()});
 it('animates, pauses and scrubs isolated test-only radar frame metadata',()=>{
  vi.useFakeTimers();fixture.result={provider:'RainViewer TEST FIXTURE',kind:'test-only frames',status:'ok',available:true,fetched_at:'2025-01-01T00:00:00Z',data:{frames:[{time:1000,url:'https://example.invalid/test-frame-1'},{time:1600,url:'https://example.invalid/test-frame-2'}]}};
  render(<RadarPanel place={place} onPlace={()=>{}}/>);expect(screen.getByTestId('radar-map')).toHaveAttribute('data-frame','1600');fireEvent.click(screen.getByRole('button',{name:'Play radar animation'}));act(()=>vi.advanceTimersByTime(1500));expect(screen.getByTestId('radar-map')).toHaveAttribute('data-frame','1000');fireEvent.click(screen.getByRole('button',{name:'Pause radar animation'}));act(()=>vi.advanceTimersByTime(3000));expect(screen.getByTestId('radar-map')).toHaveAttribute('data-frame','1000');fireEvent.change(screen.getByLabelText('Radar timeline'),{target:{value:'1'}});expect(screen.getByTestId('radar-map')).toHaveAttribute('data-frame','1600');
 });
 it('labels weather codes in plain language',()=>{expect(condition(0)).toBe('Clear sky');expect(condition(63)).toBe('Rain');expect(condition(95)).toBe('Thunderstorms');expect(condition(null)).toBe('Conditions unavailable')});
});
