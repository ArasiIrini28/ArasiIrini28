from celery import Celery
from backend.app.config import settings
from backend.app.alerts import collect, retention

app = Celery('earthvision', broker=settings.redis_url, backend=settings.redis_url)
app.conf.update(timezone='UTC', task_serializer='json', accept_content=['json'], result_serializer='json',
                beat_schedule={'collect-every-15m': {'task': 'workers.tasks.collect_data', 'schedule': 900},
                               'retain-daily': {'task': 'workers.tasks.retain', 'schedule': 86400}})


@app.task
def collect_data():
    return collect()


@app.task
def retain():
    retention()
