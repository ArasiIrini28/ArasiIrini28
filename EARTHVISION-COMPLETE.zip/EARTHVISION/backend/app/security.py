import hashlib
import secrets
from datetime import timedelta
from argon2 import PasswordHasher
from argon2.exceptions import VerificationError, InvalidHashError
from fastapi import Depends, HTTPException, Request
from sqlalchemy import select
from .models import Session, User, get_db, now
from .config import settings

hasher = PasswordHasher(time_cost=3, memory_cost=65536, parallelism=2)
DUMMY_HASH = hasher.hash('constant-time-dummy-password-never-used')


def verify(password, password_hash):
    try:
        return hasher.verify(password_hash, password)
    except (VerificationError, InvalidHashError):
        return False


def hash_token(token):
    return hashlib.sha256(token.encode()).hexdigest()


def current_user(request: Request, db=Depends(get_db)):
    token = request.cookies.get('ev_session', '')
    session = db.scalar(select(Session).where(Session.token_hash == hash_token(token), Session.expires > now()))
    if not session:
        raise HTTPException(401, 'Sign in to use this feature.')
    return db.get(User, session.user_id)


def create_session(db, user_id, response):
    token = secrets.token_urlsafe(32)
    db.add(Session(user_id=user_id, token_hash=hash_token(token), expires=now() + timedelta(days=7)))
    db.commit()
    response.set_cookie('ev_session', token, httponly=True, secure=settings.cookie_secure,
                        samesite='lax', max_age=604800, path='/')
