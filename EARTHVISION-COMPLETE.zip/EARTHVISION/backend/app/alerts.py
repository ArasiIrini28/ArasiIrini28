import math
from datetime import timedelta
from sqlalchemy import select, delete
from . import providers, storage
from .models import (SessionLocal, Subscription, Notification, Location, FetchLog, Cache, Session,
                     AuditLog, Weather, AirQuality, now)


def distance(lat1, lon1, lat2, lon2):
    a, b = math.radians(lat1), math.radians(lat2)
    dlat, dlon = b-a, math.radians(lon2-lon1)
    h = math.sin(dlat/2)**2 + math.cos(a)*math.cos(b)*math.sin(dlon/2)**2
    return 6371 * 2 * math.asin(min(1, math.sqrt(h)))


def evaluate(db, user_id=None):
    query = select(Subscription).where(Subscription.enabled.is_(True))
    if user_id is not None:
        query = query.where(Subscription.user_id == user_id)
    generated, checked, unavailable = 0, 0, 0
    for sub in db.scalars(query).all():
        loc = db.get(Location, sub.location_id)
        checked += 1
        matches = []
        if sub.kind in ('temperature', 'rainfall', 'wind'):
            data = providers.weather(db, loc.latitude, loc.longitude)
            if data['status'] in ('ok', 'cached') and data['available']:
                current = data['data']['current']
                key = {'temperature': 'temperature_2m', 'rainfall': 'precipitation', 'wind': 'wind_speed_10m'}[sub.kind]
                value = current.get(key)
                if value is not None and value >= sub.threshold:
                    matches = [(str(current['time']), f'{loc.name}: {sub.kind} {value} exceeded {sub.threshold}. Model-derived notification; not an official warning.')]
        else:
            data = {'earthquake': lambda: providers.earthquakes(db),
                    'wildfire': lambda: providers.wildfires(db, loc.latitude, loc.longitude),
                    'disaster': lambda: providers.disasters(db)}[sub.kind]()
            if data['status'] in ('ok', 'cached') and data['available']:
                storage.persist_events(db, sub.kind, data)
                for item in data['data']:
                    magnitude = item.get('magnitude')
                    severity = {'Green': 1, 'Orange': 2, 'Red': 3}.get(item.get('severity'), 0)
                    qualifies = (magnitude is not None and magnitude >= sub.threshold) if sub.kind == 'earthquake' else (severity >= sub.threshold if sub.kind == 'disaster' else (item.get('frp_mw') or 0) >= sub.threshold)
                    if qualifies and distance(loc.latitude, loc.longitude, item['latitude'], item['longitude']) <= sub.radius_km:
                        matches.append((str(item['id']), f"{item['title']} near {loc.name}. Third-party feed notification; consult the source for official guidance."))
        if data['status'] not in ('ok', 'cached') or not data['available']:
            unavailable += 1
        for event_key, message in matches:
            exists = db.scalar(select(Notification.id).where(Notification.subscription_id == sub.id, Notification.event_key == event_key))
            if exists is None:
                db.add(Notification(user_id=sub.user_id, subscription_id=sub.id, event_key=event_key,
                                    message=message, source=data['provider']))
                generated += 1
        db.commit()
    return {'checked': checked, 'generated': generated, 'unavailable': unavailable}


def collect():
    with SessionLocal() as db:
        return evaluate(db)


def retention():
    with SessionLocal() as db:
        for model, days in [(FetchLog, 30), (AuditLog, 90), (Weather, 365), (AirQuality, 365), (Notification, 90)]:
            db.execute(delete(model).where(model.created_at < now() - timedelta(days=days)))
        db.execute(delete(Cache).where(Cache.expires < now() - timedelta(days=7)))
        db.execute(delete(Session).where(Session.expires < now()))
        db.commit()
