import asyncio
import csv
import io
import re
import time
from collections import defaultdict, deque
from contextlib import asynccontextmanager
from datetime import date, timedelta
from functools import lru_cache
from typing import Literal
import pandas as pd
from fastapi import FastAPI, Depends, HTTPException, Query, Request, Response, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import select, delete, text
from sqlalchemy.exc import IntegrityError
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from .config import ROOT, settings
from .models import (SessionLocal, get_db, User, Preference, SavedLocation, Location, Subscription,
                     Notification, Session, AuditLog, FetchLog, MLModel, Prediction, now)
from .security import current_user, hasher, verify, DUMMY_HASH, create_session, hash_token
from . import providers, storage, alerts
from ml.pipeline import evaluate, reference, anomalies, trends


async def scheduler():
    while True:
        await asyncio.sleep(900)
        try:
            await asyncio.to_thread(alerts.collect)
            await asyncio.to_thread(alerts.retention)
        except Exception:
            # Keep the next run alive, without logging provider keys or response bodies.
            import logging
            logging.getLogger('earthvision').error('Scheduled collection failed; check database and provider status.')


@asynccontextmanager
async def lifespan(app):
    # Use Alembic on all startup paths; no hidden create_all replacement for migrations.
    from alembic.config import Config
    from alembic import command
    config = Config(str(ROOT / 'database' / 'alembic.ini'))
    command.upgrade(config, 'head')
    with SessionLocal() as db:
        storage.seed(db)
    task = asyncio.create_task(scheduler()) if settings.scheduler_enabled else None
    yield
    if task:
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass


app = FastAPI(title='EarthVision API', version='1.0.0', lifespan=lifespan,
              description='Public environmental data, provenance, user alerts, and research ML. No paid services.')
origins = settings.allowed_origins.split(',')
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=True,
                   allow_methods=['GET', 'POST', 'PATCH', 'PUT', 'DELETE'], allow_headers=['Content-Type'])
requests = defaultdict(deque)


@app.middleware('http')
async def protection(request, call_next):
    if request.url.path.startswith('/api'):
        origin = request.headers.get('origin')
        if request.method not in ('GET', 'HEAD', 'OPTIONS') and origin and origin not in origins:
            return JSONResponse({'detail': 'Origin not allowed.'}, 403)
        if request.method in ('POST', 'PUT', 'PATCH') and 'application/json' not in request.headers.get('content-type', ''):
            return JSONResponse({'detail': 'Use application/json.'}, 415)
        if int(request.headers.get('content-length', '0') or 0) > 16384:
            return JSONResponse({'detail': 'Request body too large.'}, 413)
        ip = request.client.host if request.client else 'unknown'
        bucket_key = (ip, 'auth' if request.url.path.startswith('/api/auth/') else 'api')
        bucket = requests[bucket_key]
        t = time.monotonic()
        while bucket and bucket[0] < t-60:
            bucket.popleft()
        limit = 15 if bucket_key[1] == 'auth' else settings.rate_limit
        if len(bucket) >= limit:
            return JSONResponse({'detail': 'Rate limit reached. Retry in 60 seconds.'}, 429, headers={'Retry-After': '60'})
        bucket.append(t)
        if len(requests) > 10000:
            for key in list(requests):
                if not requests[key] or requests[key][-1] < t-60:
                    del requests[key]
    response = await call_next(request)
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    response.headers['X-Frame-Options'] = 'DENY'
    if request.url.path.startswith('/api'):
        response.headers['Cache-Control'] = 'no-store'
    return response


@app.exception_handler(IntegrityError)
async def conflict(request, exc):
    return JSONResponse({'detail': 'This record already exists or conflicts with another update.'}, 409)


class Coordinates(BaseModel):
    latitude: float = Field(ge=-90, le=90, allow_inf_nan=False)
    longitude: float = Field(ge=-180, le=180, allow_inf_nan=False)


def coords(latitude: float = Query(20.5937, ge=-90, le=90), longitude: float = Query(78.9629, ge=-180, le=180)):
    if not (-90 <= latitude <= 90 and -180 <= longitude <= 180):
        raise HTTPException(422, 'Invalid coordinates')
    return latitude, longitude


def date_range(start, end):
    if end < start or end > date.today() - timedelta(days=5) or (end-start).days > 1826:
        raise HTTPException(422, 'Use an ordered range of at most five years ending at least five days ago.')


def frame_from_history(result):
    if not result['available']:
        raise HTTPException(503, result['message'])
    d = result['data']['daily']
    return pd.DataFrame({'date': d['time'], 'temp_max': d['temperature_2m_max'], 'temp_min': d['temperature_2m_min'],
                         'precipitation': d['precipitation_sum'], 'wind': d['wind_speed_10m_max']})


def user_json(user):
    return {'id': user.id, 'email': user.email, 'name': user.name}


def row_json(row):
    return {column.name: getattr(row, column.name) for column in row.__table__.columns}


@app.get('/api/health')
def health(db=Depends(get_db)):
    db.execute(text('SELECT 1'))
    return {'status': 'ok', 'database': 'connected', 'version': '1.0.0', 'budget': '₹0 local software',
            'scheduler': settings.scheduler_enabled}


@app.get('/api/sources')
def sources(db=Depends(get_db)):
    result = []
    for name, (url, license) in providers.PROVIDERS.items():
        latest = db.scalar(select(FetchLog).where(FetchLog.provider == name).order_by(FetchLog.id.desc()))
        result.append({'name': name, 'url': url, 'license': license,
                       'status': latest.status if latest else 'not fetched', 'last_attempt': latest.created_at if latest else None})
    return result


@app.get('/api/weather')
@app.get('/api/weather/current')
@app.get('/api/weather/forecast')
def weather(point=Depends(coords), db=Depends(get_db)):
    return storage.persist_weather(db, *point, providers.weather(db, *point))


@app.get('/api/weather/history')
def history(start: date, end: date, point=Depends(coords), db=Depends(get_db)):
    date_range(start, end)
    return providers.weather(db, *point, start, end)


@app.get('/api/locations/search')
def search(q: str = Query(min_length=2, max_length=100), db=Depends(get_db)):
    return providers.search(db, q)


@app.get('/api/radar')
def radar(db=Depends(get_db)):
    return providers.radar(db)


@app.get('/api/satellite')
def satellite(day: date = Query(default=date.today()-timedelta(days=2))):
    if day > date.today() or day < date(2000, 2, 24):
        raise HTTPException(422, 'Select a date between 2000-02-24 and today. Terra and Aqua have different coverage periods.')
    if not settings.provider_network_enabled:
        return providers.envelope('NASA GIBS', 'satellite observations', status='verification_pending',
                                  message='Satellite requests are disabled while provider verification is pending.')
    return providers.satellite(day)


def page(result, offset, limit):
    if result['available']:
        return {**result, 'total': len(result['data']), 'offset': offset, 'limit': limit, 'data': result['data'][offset:offset+limit]}
    return result


@app.get('/api/earthquakes')
def earthquakes(offset: int = Query(0, ge=0), limit: int = Query(100, ge=1, le=1000), db=Depends(get_db)):
    return page(storage.persist_events(db, 'earthquake', providers.earthquakes(db)), offset, limit)


@app.get('/api/wildfires')
def wildfires(point=Depends(coords), offset: int = Query(0, ge=0), limit: int = Query(100, ge=1, le=1000), db=Depends(get_db)):
    return page(storage.persist_events(db, 'wildfire', providers.wildfires(db, *point)), offset, limit)


@app.get('/api/disasters')
def disasters(offset: int = Query(0, ge=0), limit: int = Query(100, ge=1, le=1000), db=Depends(get_db)):
    return page(storage.persist_events(db, 'disaster', providers.disasters(db)), offset, limit)


@app.get('/api/air-quality')
def air_quality(mode: Literal['model', 'observations'] = 'model', point=Depends(coords), db=Depends(get_db)):
    return storage.persist_air(db, *point, providers.air_quality(db, *point, mode))


@app.get('/api/air-quality/history')
def air_history(sensor_id: int = Query(ge=1), start: date = Query(), end: date = Query(), db=Depends(get_db)):
    date_range(start, end)
    return providers.aq_history(db, sensor_id, start, end)


@app.get('/api/analytics')
def analytics(start: date, end: date, point=Depends(coords), db=Depends(get_db)):
    date_range(start, end)
    data = providers.weather(db, *point, start, end)
    if data['available']:
        data = {**data, 'trends': trends(frame_from_history(data)), 'summary': 'Linear trends over the selected range; seasonal effects are not removed. This is not a long-term climate attribution.'}
    return data


@app.get('/api/reports/{format}')
def report(format: Literal['csv', 'pdf'], start: date, end: date, point=Depends(coords), db=Depends(get_db)):
    date_range(start, end)
    data = providers.weather(db, *point, start, end)
    frame = frame_from_history(data)
    rows = frame.to_dict('records')
    if format == 'csv':
        output = io.StringIO()
        writer = csv.DictWriter(output, fieldnames=list(frame.columns)+['provider', 'kind', 'fetched_at', 'status', 'latitude', 'longitude'])
        writer.writeheader()
        for row in rows:
            writer.writerow({**row, **{k: data[k] for k in ('provider', 'kind', 'fetched_at', 'status')}, 'latitude': point[0], 'longitude': point[1]})
        content, mime = output.getvalue(), 'text/csv'
    else:
        output = io.BytesIO()
        pdf = canvas.Canvas(output, pagesize=A4)
        y = 800
        lines = ['EarthVision - Historical weather report', f'Coordinates: {point[0]}, {point[1]} | {start} to {end}',
                 f"Source: {data['provider']} | {data['kind']} | {data['status']}", f"Retrieved: {data['fetched_at']}",
                 'Attribution: Open-Meteo, CC BY 4.0', 'Date           Max C    Min C    Rain mm   Wind km/h']
        lines += [f"{r['date']}      {r['temp_max']}      {r['temp_min']}      {r['precipitation']}      {r['wind']}" for r in rows]
        for line in lines:
            if y < 50:
                pdf.showPage()
                y = 800
            pdf.setFont('Helvetica', 10)
            pdf.drawString(40, y, line)
            y -= 17
        pdf.save()
        content, mime = output.getvalue(), 'application/pdf'
    return Response(content, media_type=mime, headers={'Content-Disposition': f'attachment; filename="earthvision-{start}-{end}.{format}"'})


@lru_cache(maxsize=1)
def reference_evaluation():
    return evaluate(reference(), 'Seattle 2012–2015; Vega datasets / NOAA; historical reference benchmark')


@app.get('/api/ml/predict')
def predict(db=Depends(get_db)):
    result = reference_evaluation()
    model = db.scalar(select(MLModel).where(MLModel.fingerprint == result['fingerprint']))
    if model is None:
        model = MLModel(fingerprint=result['fingerprint'], name=result['selected_model'], metrics=result)
        db.add(model)
        db.flush()
        db.add(Prediction(model_id=model.id, target_date=result['prediction']['date'], value=result['prediction']['value']))
        db.commit()
    return result


class TrainRequest(Coordinates):
    start: date
    end: date


@app.post('/api/ml/train')
def train(body: TrainRequest, user=Depends(current_user), db=Depends(get_db)):
    date_range(body.start, body.end)
    data = providers.weather(db, body.latitude, body.longitude, body.start, body.end)
    try:
        result = evaluate(frame_from_history(data), f"Open-Meteo reanalysis at {body.latitude}, {body.longitude}; {data['fetched_at']}")
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc
    model = db.scalar(select(MLModel).where(MLModel.fingerprint == result['fingerprint']))
    if model is None:
        model = MLModel(fingerprint=result['fingerprint'], name=result['selected_model'], metrics=result)
        db.add(model)
        db.flush()
        db.add(Prediction(model_id=model.id, target_date=result['prediction']['date'], value=result['prediction']['value']))
        db.commit()
    return result


@app.get('/api/ml/anomalies')
def anomaly_reference():
    return {**anomalies(reference()), 'trends': trends(reference()), 'source': 'Seattle 2012–2015 historical reference'}


@app.get('/api/ml/summary')
def summary(point=Depends(coords), db=Depends(get_db)):
    result = providers.weather(db, *point)
    current = (result.get('data') or {}).get('current', {})
    parts = []
    for field, name, unit in [('temperature_2m', 'Temperature', '°C'), ('precipitation', 'Precipitation', 'mm'), ('wind_speed_10m', 'Wind', 'km/h')]:
        if current.get(field) is not None:
            parts.append(f'{name}: {current[field]} {unit}')
    return {**result, 'interpretation': '; '.join(parts) if parts else 'No retrieved measurements available to summarize.',
            'method': 'Deterministic, data-grounded automated interpretation; no external LLM or paid API.'}


class Credentials(BaseModel):
    email: str = Field(min_length=5, max_length=254)
    password: str = Field(min_length=10, max_length=128)
    name: str = Field(default='Explorer', min_length=1, max_length=80)

    @field_validator('email')
    @classmethod
    def email_valid(cls, value):
        value = value.strip().lower()
        if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+', value):
            raise ValueError('Enter a valid email address.')
        return value


@app.post('/api/auth/register', status_code=201)
def register(body: Credentials, response: Response, db=Depends(get_db)):
    if db.scalar(select(User.id).where(User.email == body.email)):
        raise HTTPException(409, 'Account already exists.')
    user = User(email=body.email, name=body.name, password_hash=hasher.hash(body.password))
    db.add(user)
    db.flush()
    db.add(Preference(user_id=user.id))
    db.add(AuditLog(user_id=user.id, action='register'))
    create_session(db, user.id, response)
    return user_json(user)


@app.post('/api/auth/login')
def login(body: Credentials, response: Response, db=Depends(get_db)):
    user = db.scalar(select(User).where(User.email == body.email))
    valid = verify(body.password, user.password_hash if user else DUMMY_HASH)
    if not valid or not user:
        raise HTTPException(401, 'Invalid email or password.')
    db.add(AuditLog(user_id=user.id, action='login'))
    create_session(db, user.id, response)
    return user_json(user)


@app.post('/api/auth/logout')
def logout(request: Request, response: Response, db=Depends(get_db)):
    db.execute(delete(Session).where(Session.token_hash == hash_token(request.cookies.get('ev_session', ''))))
    db.commit()
    response.delete_cookie('ev_session', path='/')
    return {'ok': True}


@app.get('/api/auth')
@app.get('/api/users/me')
def me(user=Depends(current_user)):
    return user_json(user)


class Preferences(BaseModel):
    theme: Literal['dark', 'light'] = 'dark'
    units: Literal['metric', 'imperial'] = 'metric'
    home_page: Literal['overview', 'map', 'weather', 'satellite', 'earthquakes', 'wildfires', 'air-quality', 'disasters', 'ml', 'analytics', 'alerts', 'profile', 'about'] = 'overview'


@app.get('/api/users/preferences')
def preferences(user=Depends(current_user), db=Depends(get_db)):
    return row_json(db.scalar(select(Preference).where(Preference.user_id == user.id)))


@app.put('/api/users/preferences')
def set_preferences(body: Preferences, user=Depends(current_user), db=Depends(get_db)):
    item = db.scalar(select(Preference).where(Preference.user_id == user.id))
    for key, value in body.model_dump().items():
        setattr(item, key, value)
    db.commit()
    return row_json(item)


class SaveLocation(Coordinates):
    name: str = Field(min_length=1, max_length=150)


@app.get('/api/locations')
def saved(user=Depends(current_user), db=Depends(get_db)):
    return [row_json(loc) for loc in db.scalars(select(Location).join(SavedLocation).where(SavedLocation.user_id == user.id))]


@app.post('/api/locations', status_code=201)
def save_location(body: SaveLocation, user=Depends(current_user), db=Depends(get_db)):
    loc = storage.location(db, body.latitude, body.longitude, body.name)
    if not db.scalar(select(SavedLocation.id).where(SavedLocation.user_id == user.id, SavedLocation.location_id == loc.id)):
        db.add(SavedLocation(user_id=user.id, location_id=loc.id))
    db.commit()
    return row_json(loc)


@app.delete('/api/locations/{location_id}')
def remove_location(location_id: int, user=Depends(current_user), db=Depends(get_db)):
    db.execute(delete(SavedLocation).where(SavedLocation.user_id == user.id, SavedLocation.location_id == location_id))
    db.commit()
    return {'ok': True}


class AlertBody(Coordinates):
    name: str = Field(min_length=1, max_length=150)
    kind: Literal['temperature', 'rainfall', 'wind', 'earthquake', 'wildfire', 'disaster']
    threshold: float = Field(ge=-100, le=1000, allow_inf_nan=False)
    radius_km: float = Field(default=250, gt=0, le=20000, allow_inf_nan=False)


@app.get('/api/alerts')
def subscriptions(user=Depends(current_user), db=Depends(get_db)):
    return [{**row_json(item), 'location': row_json(db.get(Location, item.location_id))} for item in db.scalars(select(Subscription).where(Subscription.user_id == user.id))]


@app.post('/api/alerts', status_code=201)
def subscribe(body: AlertBody, user=Depends(current_user), db=Depends(get_db)):
    if len(db.scalars(select(Subscription.id).where(Subscription.user_id == user.id)).all()) >= 20:
        raise HTTPException(422, 'Maximum 20 subscriptions per account.')
    if body.kind != 'temperature' and body.threshold < 0:
        raise HTTPException(422, 'This threshold must be non-negative.')
    if body.kind == 'disaster' and body.threshold not in (1, 2, 3):
        raise HTTPException(422, 'GDACS severity is 1 Green, 2 Orange, or 3 Red.')
    loc = storage.location(db, body.latitude, body.longitude, body.name)
    sub = Subscription(user_id=user.id, location_id=loc.id, kind=body.kind, threshold=body.threshold, radius_km=body.radius_km)
    db.add(sub)
    db.commit()
    return row_json(sub)


@app.delete('/api/alerts/{subscription_id}')
def unsubscribe(subscription_id: int, user=Depends(current_user), db=Depends(get_db)):
    row = db.scalar(select(Subscription).where(Subscription.id == subscription_id, Subscription.user_id == user.id))
    if not row:
        raise HTTPException(404, 'Subscription not found.')
    db.delete(row)
    db.commit()
    return {'ok': True}


@app.post('/api/alerts/check')
def check_alerts(user=Depends(current_user), db=Depends(get_db)):
    return alerts.evaluate(db, user.id)


@app.get('/api/notifications')
def notifications(offset: int = Query(0, ge=0), limit: int = Query(50, ge=1, le=200), user=Depends(current_user), db=Depends(get_db)):
    return [row_json(row) for row in db.scalars(select(Notification).where(Notification.user_id == user.id).order_by(Notification.id.desc()).offset(offset).limit(limit))]


@app.patch('/api/notifications/{notification_id}/read')
def mark_read(notification_id: int, user=Depends(current_user), db=Depends(get_db)):
    item = db.scalar(select(Notification).where(Notification.id == notification_id, Notification.user_id == user.id))
    if item is None:
        raise HTTPException(404, 'Notification not found.')
    item.read = True
    db.commit()
    return row_json(item)


@app.websocket('/api/ws/notifications')
async def notification_socket(websocket: WebSocket):
    if websocket.headers.get('origin') not in origins:
        await websocket.close(code=1008)
        return
    token = websocket.cookies.get('ev_session', '')
    await websocket.accept()
    try:
        previous = None
        while True:
            with SessionLocal() as db:
                session = db.scalar(select(Session).where(Session.token_hash == hash_token(token), Session.expires > now()))
                if not session:
                    await websocket.close(code=1008)
                    return
                count = len(db.scalars(select(Notification.id).where(Notification.user_id == session.user_id, Notification.read.is_(False))).all())
            if count != previous:
                await websocket.send_json({'unread': count})
                previous = count
            await asyncio.sleep(5)
    except WebSocketDisconnect:
        pass


DIST = ROOT / 'frontend' / 'dist'
if DIST.exists():
    app.mount('/assets', StaticFiles(directory=DIST / 'assets'), name='assets')


@app.get('/{path:path}', include_in_schema=False)
def frontend(path: str):
    if path.startswith('api/'):
        raise HTTPException(404, 'API route not found.')
    candidate = (DIST / path).resolve()
    if candidate.is_relative_to(DIST.resolve()) and candidate.is_file():
        return FileResponse(candidate)
    if (DIST / 'index.html').exists():
        return FileResponse(DIST / 'index.html')
    return JSONResponse({'message': 'Build frontend with npm ci && npm run build in frontend/, then restart. API docs: /docs'}, 503)
