"""Public provider adapters. No synthetic observations or implicit provider substitution."""
import csv
import hashlib
import io
import json
from datetime import date, timedelta
from threading import RLock
import httpx
from sqlalchemy import select
from .config import settings
from .models import Cache, FetchLog, now

PROVIDERS = {
    'RainViewer': ('https://www.rainviewer.com/api.html', 'RainViewer free personal/non-commercial radar; attribution required'),
    'Open-Meteo': ('https://open-meteo.com', 'CC BY 4.0 data; free API non-commercial only'),
    'NASA GIBS': ('https://nasa-gibs.github.io/gibs-api-docs/', 'NASA open data; credit NASA GIBS'),
    'USGS': ('https://earthquake.usgs.gov', 'US government public domain; credit USGS'),
    'NASA FIRMS': ('https://firms.modaps.eosdis.nasa.gov', 'NASA open data; free MAP_KEY required'),
    'OpenAQ': ('https://openaq.org', 'Underlying provider licences vary; preserve attribution'),
    'GDACS': ('https://www.gdacs.org', 'Credit GDACS, EC and UN; consult source terms'),
    'Open-Meteo CAMS': ('https://open-meteo.com/en/docs/air-quality-api', 'CC BY 4.0; credit CAMS ENSEMBLE and Open-Meteo'),
}
LOCK = RLock()


def envelope(provider, kind, data=None, status='ok', message=None, source_time=None):
    return {'provider': provider, 'kind': kind, 'status': status, 'available': data is not None,
            'fetched_at': now().isoformat() + 'Z', 'source_time': source_time,
            'attribution': PROVIDERS.get(provider, ('', ''))[1], 'message': message, 'data': data}


def fetch(db, provider, kind, url, params=None, headers=None, ttl=600, parser=None, cache_tag=''):
    if not settings.provider_network_enabled:
        return envelope(provider, kind, status='verification_pending',
                        message='Provider network access is disabled in this run while verification is pending. No live values are supplied.')
    # Never store URLs/headers: FIRMS puts its secret in the URL path.
    key = hashlib.sha256(json.dumps([provider, kind, params, cache_tag], sort_keys=True).encode()).hexdigest()
    with LOCK:
        cached = db.scalar(select(Cache).where(Cache.key == key))
        if cached and cached.expires > now():
            return {**cached.payload, 'status': 'cached'} if cached.payload['status'] == 'ok' else cached.payload
        try:
            with httpx.Client(timeout=settings.fetch_timeout, follow_redirects=False) as client:
                response = client.get(url, params=params, headers=headers)
                response.raise_for_status()
                if len(response.content) > 15_000_000:
                    raise ValueError('Response too large')
                data = parser(response) if parser else response.json()
            result = envelope(provider, kind, data)
            db.add(FetchLog(provider=provider, status='ok', detail='Fetch succeeded'))
            if cached:
                cached.payload, cached.expires = result, now() + timedelta(seconds=ttl)
            else:
                db.add(Cache(key=key, payload=result, expires=now() + timedelta(seconds=ttl)))
            db.commit()
            return result
        except (httpx.HTTPError, ValueError, KeyError, TypeError, IndexError):
            # Exceptions can contain credentials; never return or log their text.
            message = 'Provider could not be reached or returned invalid data. Check network access and provider configuration.'
            db.add(FetchLog(provider=provider, status='unavailable', detail=message))
            if cached and cached.payload['available']:
                result = {**cached.payload, 'status': 'stale', 'message': message}
                cached.payload, cached.expires = result, now() + timedelta(seconds=60)
            else:
                result = envelope(provider, kind, status='unavailable', message=message)
                if cached:
                    cached.payload, cached.expires = result, now() + timedelta(seconds=60)
                else:
                    db.add(Cache(key=key, payload=result, expires=now() + timedelta(seconds=60)))
            db.commit()
            return result


def weather(db, lat, lon, start=None, end=None):
    params = {'latitude': lat, 'longitude': lon, 'timezone': 'UTC'}
    daily = 'temperature_2m_max,temperature_2m_min,precipitation_sum,wind_speed_10m_max'
    if start:
        params.update(start_date=str(start), end_date=str(end), daily=daily)
        url, kind, ttl = 'https://archive-api.open-meteo.com/v1/archive', 'reanalysis', 86400
    else:
        fields = 'temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,cloud_cover,wind_speed_10m,wind_direction_10m'
        params.update(current=fields, hourly=fields+',precipitation_probability',
                      daily=daily+',weather_code,precipitation_probability_max,sunrise,sunset', forecast_days=10)
        url, kind, ttl = 'https://api.open-meteo.com/v1/forecast', 'model forecast', 900
    def parse(response):
        data = response.json()
        if 'daily' not in data or (not start and 'current' not in data):
            raise ValueError('Missing weather fields')
        return data
    result = fetch(db, 'Open-Meteo', kind, url, params, ttl=ttl, parser=parse)
    if result['data']:
        result = {**result, 'source_time': result['data'].get('current', {}).get('time') or str(end)}
    return result


def search(db, query):
    return fetch(db, 'Open-Meteo', 'geocoding', 'https://geocoding-api.open-meteo.com/v1/search',
                 {'name': query, 'count': 10, 'language': 'en', 'format': 'json'}, ttl=86400)


def earthquakes(db):
    def parse(response):
        return [{'id': f['id'], 'latitude': f['geometry']['coordinates'][1],
                 'longitude': f['geometry']['coordinates'][0], 'depth_km': f['geometry']['coordinates'][2],
                 'magnitude': f['properties']['mag'], 'title': f['properties']['place'] or 'Unspecified location',
                 'time': f['properties']['time'], 'url': f['properties'].get('url'),
                 'updated': f['properties'].get('updated')} for f in response.json()['features']]
    return fetch(db, 'USGS', 'event observations',
                 'https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_day.geojson', ttl=300, parser=parse)


def wildfires(db, lat, lon):
    if not settings.firms_map_key:
        return envelope('NASA FIRMS', 'satellite detections', status='key_required',
                        message='Add a free FIRMS_MAP_KEY to the backend .env. Request one at firms.modaps.eosdis.nasa.gov/api/map_key/.')
    area = f'{max(-180,lon-5)},{max(-90,lat-5)},{min(180,lon+5)},{min(90,lat+5)}'
    def parse(response):
        rows = list(csv.DictReader(io.StringIO(response.text)))
        result = []
        for row in rows:
            result.append({'id': hashlib.sha256(json.dumps(row, sort_keys=True).encode()).hexdigest(),
                           'latitude': float(row['latitude']), 'longitude': float(row['longitude']),
                           'time': row['acq_date'] + 'T' + row['acq_time'].zfill(4)[:2] + ':' + row['acq_time'].zfill(4)[2:] + ':00Z',
                           'title': 'VIIRS active-fire detection', 'confidence': row.get('confidence'),
                           'frp_mw': float(row['frp']) if row.get('frp') else None, 'instrument': row.get('instrument', 'VIIRS')})
        if not rows and 'latitude' not in response.text:
            raise ValueError('Invalid FIRMS response')
        return result
    return fetch(db, 'NASA FIRMS', 'satellite detections',
                 f'https://firms.modaps.eosdis.nasa.gov/api/area/csv/{settings.firms_map_key}/VIIRS_NOAA20_NRT/{area}/1',
                 ttl=1800, parser=parse, cache_tag=area)


def disasters(db):
    def parse(response):
        result = []
        for f in response.json()['features']:
            p, g = f['properties'], f.get('geometry')
            if not g or g['type'] != 'Point':
                continue
            result.append({'id': f"{p.get('eventtype')}-{p.get('eventid')}-{p.get('episodeid', '')}",
                           'latitude': g['coordinates'][1], 'longitude': g['coordinates'][0],
                           'title': p.get('name') or p.get('description') or p.get('eventtype', 'Disaster'),
                           'time': p.get('fromdate'), 'severity': p.get('alertlevel'),
                           'event_type': p.get('eventtype'), 'url': p.get('url', {}).get('report') if isinstance(p.get('url'), dict) else p.get('url')})
        return result
    return fetch(db, 'GDACS', 'third-party event alerts',
                 'https://www.gdacs.org/gdacsapi/api/events/geteventlist/MAP', ttl=900, parser=parse)


def air_quality(db, lat, lon, mode='model'):
    if mode == 'model':
        fields = 'pm10,pm2_5,carbon_monoxide,nitrogen_dioxide,ozone,sulphur_dioxide'
        return fetch(db, 'Open-Meteo CAMS', 'model forecast (not station observations)',
                     'https://air-quality-api.open-meteo.com/v1/air-quality',
                     {'latitude': lat, 'longitude': lon, 'current': fields, 'hourly': fields, 'timezone': 'UTC'}, ttl=3600)
    if not settings.openaq_api_key:
        return envelope('OpenAQ', 'station observations', status='key_required',
                        message='Add a free OPENAQ_API_KEY to the backend .env for station observations. The separate CAMS view is model data.')
    headers = {'X-API-Key': settings.openaq_api_key}
    found = fetch(db, 'OpenAQ', 'station lookup', 'https://api.openaq.org/v3/locations',
                  {'coordinates': f'{lat},{lon}', 'radius': 25000, 'limit': 5}, headers, ttl=3600)
    if not found['available']:
        return found
    stations, errors = [], []
    for station in found['data'].get('results', []):
        latest = fetch(db, 'OpenAQ', 'station observations', f"https://api.openaq.org/v3/locations/{station['id']}/latest",
                       headers=headers, ttl=3600, cache_tag=str(station['id']))
        sensors = {s['id']: s for s in station.get('sensors', [])}
        if not latest['available']:
            errors.append(station['name'])
            continue
        for measurement in latest['data'].get('results', []):
            sensor = sensors.get(measurement['sensorsId'], {})
            stations.append({**measurement, 'station': station['name'], 'parameter': sensor.get('parameter'),
                             'provider': station.get('provider'), 'attribution': station.get('licenses'),
                             'fetch_status': latest['status'], 'fetched_at': latest['fetched_at']})
    result = envelope('OpenAQ', 'station observations', stations,
                      status='partial' if errors else 'ok', message='Some stations unavailable' if errors else None)
    if any(s['fetch_status'] == 'stale' for s in stations):
        result['status'] = 'stale'
    return result


def aq_history(db, sensor_id, start, end):
    if not settings.openaq_api_key:
        return envelope('OpenAQ', 'station observations', status='key_required', message='Configure free OPENAQ_API_KEY.')
    return fetch(db, 'OpenAQ', 'station history', f'https://api.openaq.org/v3/sensors/{sensor_id}/days',
                 {'date_from': str(start), 'date_to': str(end), 'limit': 1000},
                 {'X-API-Key': settings.openaq_api_key}, ttl=3600, cache_tag=str(sensor_id))


def satellite(day: date):
    return envelope('NASA GIBS', 'satellite observations', [
        {'id': identifier, 'title': title, 'date': str(day), 'maxzoom': 9,
         'url': f'https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/{identifier}/default/{day}/GoogleMapsCompatible_Level9/{{z}}/{{y}}/{{x}}.jpg'}
        for identifier, title in [('MODIS_Terra_CorrectedReflectance_TrueColor', 'Terra · True color'),
                                  ('MODIS_Aqua_CorrectedReflectance_TrueColor', 'Aqua · True color')]],
        status='configured', message='Imagery availability is checked by the map as tiles load; gaps and delays are possible.', source_time=str(day))


def radar(db):
    """Past observed radar only. No paid RainViewer nowcast/extended history."""
    def parse(response):
        payload = response.json()
        if payload.get('host') != 'https://tilecache.rainviewer.com':
            raise ValueError('Unexpected radar tile host')
        frames = []
        import re
        for frame in payload['radar']['past'][-13:]:
            path = frame['path']
            if not re.fullmatch(r'/v2/radar/[a-zA-Z0-9_-]+', path):
                raise ValueError('Invalid radar frame path')
            frames.append({'time': int(frame['time']), 'path': path,
                           'url': f'https://tilecache.rainviewer.com{path}/512/{{z}}/{{x}}/{{y}}/2/1_1.png'})
        return {'frames': sorted(frames, key=lambda f: f['time']), 'generated': payload.get('generated'),
                'maxzoom': 7, 'tile_size': 512, 'coverage': 'Radar coverage varies by country and station; an empty area is not proof of no rain.'}
    return fetch(db, 'RainViewer', 'past radar observations', 'https://api.rainviewer.com/public/weather-maps.json',
                 ttl=600, parser=parse)
