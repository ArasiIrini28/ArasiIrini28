"""Portable relational schema: SQLite quick start, MySQL 8 deployment."""
from datetime import datetime, timezone
from sqlalchemy import (JSON, Boolean, DateTime, Float, ForeignKey, String,
                        Text, UniqueConstraint, create_engine, event)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker
from .config import settings


def now():
    return datetime.now(timezone.utc).replace(tzinfo=None)


class Base(DeclarativeBase):
    pass


class Record(Base):
    __abstract__ = True
    id: Mapped[int] = mapped_column(primary_key=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=now, index=True)


class DataSource(Record):
    __tablename__ = 'data_sources'
    name: Mapped[str] = mapped_column(String(80), unique=True)
    url: Mapped[str] = mapped_column(String(500))
    license: Mapped[str] = mapped_column(String(500))


class User(Record):
    __tablename__ = 'users'
    email: Mapped[str] = mapped_column(String(254), unique=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    name: Mapped[str] = mapped_column(String(80))


class Session(Record):
    __tablename__ = 'sessions'
    token_hash: Mapped[str] = mapped_column(String(64), unique=True)
    user_id: Mapped[int] = mapped_column(ForeignKey('users.id', ondelete='CASCADE'), index=True)
    expires: Mapped[datetime] = mapped_column(DateTime, index=True)


class Preference(Record):
    __tablename__ = 'user_preferences'
    user_id: Mapped[int] = mapped_column(ForeignKey('users.id', ondelete='CASCADE'), unique=True)
    theme: Mapped[str] = mapped_column(String(10), default='dark')
    units: Mapped[str] = mapped_column(String(10), default='metric')
    home_page: Mapped[str] = mapped_column(String(30), default='overview')


class Location(Record):
    __tablename__ = 'locations'
    name: Mapped[str] = mapped_column(String(150))
    latitude: Mapped[float] = mapped_column(Float)
    longitude: Mapped[float] = mapped_column(Float)
    __table_args__ = (UniqueConstraint('latitude', 'longitude'),)


class SavedLocation(Record):
    __tablename__ = 'saved_locations'
    user_id: Mapped[int] = mapped_column(ForeignKey('users.id', ondelete='CASCADE'), index=True)
    location_id: Mapped[int] = mapped_column(ForeignKey('locations.id'))
    __table_args__ = (UniqueConstraint('user_id', 'location_id'),)


class Weather(Record):
    __tablename__ = 'weather_data'
    location_id: Mapped[int] = mapped_column(ForeignKey('locations.id'), index=True)
    source_id: Mapped[int] = mapped_column(ForeignKey('data_sources.id'))
    observed_at: Mapped[str] = mapped_column(String(40))
    kind: Mapped[str] = mapped_column(String(24))
    temperature: Mapped[float | None] = mapped_column(Float)
    humidity: Mapped[float | None] = mapped_column(Float)
    cloud_cover: Mapped[float | None] = mapped_column(Float)
    __table_args__ = (UniqueConstraint('location_id', 'source_id', 'observed_at', 'kind'),)


class Rainfall(Record):
    __tablename__ = 'rainfall_data'
    weather_id: Mapped[int] = mapped_column(ForeignKey('weather_data.id', ondelete='CASCADE'), unique=True)
    millimeters: Mapped[float | None] = mapped_column(Float)


class Wind(Record):
    __tablename__ = 'wind_data'
    weather_id: Mapped[int] = mapped_column(ForeignKey('weather_data.id', ondelete='CASCADE'), unique=True)
    speed_kmh: Mapped[float | None] = mapped_column(Float)
    direction: Mapped[float | None] = mapped_column(Float)


class AirQuality(Record):
    __tablename__ = 'air_quality'
    location_id: Mapped[int] = mapped_column(ForeignKey('locations.id'), index=True)
    source_id: Mapped[int] = mapped_column(ForeignKey('data_sources.id'))
    observed_at: Mapped[str] = mapped_column(String(40))
    parameter: Mapped[str] = mapped_column(String(40))
    value: Mapped[float] = mapped_column(Float)
    unit: Mapped[str] = mapped_column(String(30))
    sensor: Mapped[str] = mapped_column(String(80))
    __table_args__ = (UniqueConstraint('location_id', 'source_id', 'observed_at', 'parameter', 'sensor'),)


class EventRecord(Record):
    __abstract__ = True
    external_id: Mapped[str] = mapped_column(String(190), unique=True)
    source_id: Mapped[int] = mapped_column(ForeignKey('data_sources.id'))
    latitude: Mapped[float] = mapped_column(Float)
    longitude: Mapped[float] = mapped_column(Float)
    event_time: Mapped[str] = mapped_column(String(60), index=True)
    title: Mapped[str] = mapped_column(String(500))
    details: Mapped[dict] = mapped_column(JSON)


class Earthquake(EventRecord):
    __tablename__ = 'earthquakes'


class Wildfire(EventRecord):
    __tablename__ = 'wildfires'


class Disaster(EventRecord):
    __tablename__ = 'disaster_events'


class SatelliteLayer(Record):
    __tablename__ = 'satellite_layers'
    identifier: Mapped[str] = mapped_column(String(150), unique=True)
    title: Mapped[str] = mapped_column(String(150))
    source_id: Mapped[int] = mapped_column(ForeignKey('data_sources.id'))
    template: Mapped[str] = mapped_column(String(500))


class Subscription(Record):
    __tablename__ = 'alert_subscriptions'
    user_id: Mapped[int] = mapped_column(ForeignKey('users.id', ondelete='CASCADE'), index=True)
    location_id: Mapped[int] = mapped_column(ForeignKey('locations.id'))
    kind: Mapped[str] = mapped_column(String(20))
    threshold: Mapped[float] = mapped_column(Float)
    radius_km: Mapped[float] = mapped_column(Float, default=250)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)


class Notification(Record):
    __tablename__ = 'notification_logs'
    user_id: Mapped[int] = mapped_column(ForeignKey('users.id', ondelete='CASCADE'), index=True)
    subscription_id: Mapped[int] = mapped_column(ForeignKey('alert_subscriptions.id', ondelete='CASCADE'))
    event_key: Mapped[str] = mapped_column(String(190))
    message: Mapped[str] = mapped_column(Text)
    source: Mapped[str] = mapped_column(String(80))
    read: Mapped[bool] = mapped_column(Boolean, default=False)
    __table_args__ = (UniqueConstraint('subscription_id', 'event_key'),)


class MLModel(Record):
    __tablename__ = 'ml_models'
    fingerprint: Mapped[str] = mapped_column(String(64), unique=True)
    name: Mapped[str] = mapped_column(String(100))
    metrics: Mapped[dict] = mapped_column(JSON)


class Prediction(Record):
    __tablename__ = 'ml_predictions'
    model_id: Mapped[int] = mapped_column(ForeignKey('ml_models.id'))
    target_date: Mapped[str] = mapped_column(String(30))
    value: Mapped[float] = mapped_column(Float)
    __table_args__ = (UniqueConstraint('model_id', 'target_date'),)


class FetchLog(Record):
    __tablename__ = 'api_fetch_logs'
    provider: Mapped[str] = mapped_column(String(80), index=True)
    status: Mapped[str] = mapped_column(String(30))
    detail: Mapped[str] = mapped_column(String(200))


class AuditLog(Record):
    __tablename__ = 'audit_logs'
    user_id: Mapped[int | None] = mapped_column(ForeignKey('users.id', ondelete='SET NULL'))
    action: Mapped[str] = mapped_column(String(80))


class Cache(Record):
    __tablename__ = 'provider_cache'
    key: Mapped[str] = mapped_column(String(64), unique=True)
    payload: Mapped[dict] = mapped_column(JSON)
    expires: Mapped[datetime] = mapped_column(DateTime, index=True)


engine = create_engine(settings.database_url, pool_pre_ping=True,
                       connect_args={'check_same_thread': False, 'timeout': 30} if settings.database_url.startswith('sqlite') else {})
if settings.database_url.startswith('sqlite'):
    @event.listens_for(engine, 'connect')
    def sqlite_settings(connection, _):
        connection.execute('PRAGMA foreign_keys=ON')
        connection.execute('PRAGMA journal_mode=WAL')

SessionLocal = sessionmaker(engine, expire_on_commit=False)


def get_db():
    with SessionLocal() as db:
        yield db
