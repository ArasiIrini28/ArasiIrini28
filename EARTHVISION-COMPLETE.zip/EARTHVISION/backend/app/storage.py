"""Persistence of fetched facts, with unique source/time keys and no fake seeds."""
from sqlalchemy import select
from .models import (DataSource, Location, Weather, Rainfall, Wind, Earthquake,
                     Wildfire, Disaster, AirQuality, SatelliteLayer)
from .providers import PROVIDERS, satellite
from datetime import date


def seed(db):
    for name, (url, license) in PROVIDERS.items():
        if not db.scalar(select(DataSource).where(DataSource.name == name)):
            db.add(DataSource(name=name, url=url, license=license))
    db.commit()
    source = source_id(db, 'NASA GIBS')
    for layer in satellite(date.today())['data']:
        if not db.scalar(select(SatelliteLayer).where(SatelliteLayer.identifier == layer['id'])):
            db.add(SatelliteLayer(identifier=layer['id'], title=layer['title'], source_id=source, template=layer['url']))
    db.commit()


def source_id(db, name):
    return db.scalar(select(DataSource.id).where(DataSource.name == name))


def location(db, lat, lon, name=None):
    lat, lon = round(lat, 4), round(lon, 4)
    item = db.scalar(select(Location).where(Location.latitude == lat, Location.longitude == lon))
    if item is None:
        item = Location(latitude=lat, longitude=lon, name=name or f'{lat:.3f}, {lon:.3f}')
        db.add(item)
        db.flush()
    return item


def persist_weather(db, lat, lon, result):
    if not result['available']:
        return result
    current = result['data'].get('current')
    if not current:
        return result
    loc = location(db, lat, lon)
    src = source_id(db, result['provider'])
    row = db.scalar(select(Weather).where(Weather.location_id == loc.id, Weather.source_id == src,
                                         Weather.observed_at == current['time'], Weather.kind == result['kind']))
    if row is None:
        row = Weather(location_id=loc.id, source_id=src, observed_at=current['time'], kind=result['kind'])
        db.add(row)
        db.flush()
        db.add(Rainfall(weather_id=row.id, millimeters=current.get('precipitation')))
        db.add(Wind(weather_id=row.id, speed_kmh=current.get('wind_speed_10m'), direction=current.get('wind_direction_10m')))
    row.temperature, row.humidity, row.cloud_cover = current.get('temperature_2m'), current.get('relative_humidity_2m'), current.get('cloud_cover')
    db.commit()
    return result


def persist_events(db, kind, result):
    if not result['available']:
        return result
    cls = {'earthquake': Earthquake, 'wildfire': Wildfire, 'disaster': Disaster}[kind]
    src = source_id(db, result['provider'])
    for item in result['data']:
        row = db.scalar(select(cls).where(cls.external_id == str(item['id'])))
        if row is None:
            row = cls(external_id=str(item['id']), source_id=src)
            db.add(row)
        row.latitude, row.longitude = item['latitude'], item['longitude']
        row.title, row.event_time, row.details = str(item['title'])[:500], str(item.get('time', '')), item
    db.commit()
    return result


def persist_air(db, lat, lon, result):
    if not result['available']:
        return result
    loc, src = location(db, lat, lon), source_id(db, result['provider'])
    records = []
    if isinstance(result['data'], dict):
        current = result['data'].get('current', {})
        for parameter in ('pm2_5', 'pm10', 'ozone', 'nitrogen_dioxide', 'sulphur_dioxide', 'carbon_monoxide'):
            if current.get(parameter) is not None:
                records.append((current['time'], parameter, current[parameter], 'µg/m³', 'CAMS model'))
    else:
        for item in result['data']:
            parameter = item.get('parameter') or {}
            records.append((item['datetime']['utc'], parameter.get('name', 'unknown'), item['value'], parameter.get('units', ''), str(item['sensorsId'])))
    for timestamp, parameter, value, unit, sensor in records:
        if db.scalar(select(AirQuality.id).where(AirQuality.location_id == loc.id, AirQuality.source_id == src,
                     AirQuality.observed_at == timestamp, AirQuality.parameter == parameter, AirQuality.sensor == sensor)) is None:
            db.add(AirQuality(location_id=loc.id, source_id=src, observed_at=timestamp, parameter=parameter, value=value, unit=unit, sensor=sensor))
    db.commit()
    return result
