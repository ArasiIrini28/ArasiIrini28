#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
.venv/bin/python -m pytest -q
.venv/bin/python -m ruff check backend ml workers tests scripts
cd frontend
npm run lint
npm test
npm run build
