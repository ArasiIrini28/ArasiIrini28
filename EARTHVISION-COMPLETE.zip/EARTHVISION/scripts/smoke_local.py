"""Local-only installed-app smoke test. Registers a disposable QA account."""
import argparse
import json
import uuid
import httpx


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--url',default='http://127.0.0.1:8000')
    args=parser.parse_args()
    if httpx.URL(args.url).host not in ('localhost','127.0.0.1'):
        raise SystemExit('This smoke script only accepts localhost; do not test a real user deployment.')
    checks=[]
    with httpx.Client(base_url=args.url,timeout=30,trust_env=False) as client:
        def ok(name,condition):
            assert condition,name
            checks.append(name)
        ok('health + SQL connection',client.get('/api/health').json()['database']=='connected')
        ok('built frontend served',client.get('/').status_code==200 and 'EarthVision' in client.get('/').text)
        ok('real bundled map geometry',len(client.get('/countries.geojson').json()['features'])>200)
        for path in ('weather','radar','earthquakes','disasters','satellite'):
            result=client.get('/api/'+path)
            ok(path+' remains explicitly pending without external requests',result.status_code==200 and result.json()['status']=='verification_pending')
        email=f'qa-{uuid.uuid4().hex}@example.org'
        created=client.post('/api/auth/register',json={'email':email,'password':'Local-QA-password-482!','name':'Disposable QA'})
        ok('account registration',created.status_code==201)
        ok('authenticated profile',client.get('/api/users/me').json()['email']==email)
        loc={'name':'QA London','latitude':51.5,'longitude':-0.12}
        ok('saved location',client.post('/api/locations',json=loc).status_code==201)
        ok('preference persistence',client.put('/api/users/preferences',json={'theme':'light','units':'metric','home_page':'weather'}).status_code==200 and client.get('/api/users/preferences').json()['theme']=='light')
        ok('alert subscription',client.post('/api/alerts',json={**loc,'kind':'temperature','threshold':35}).status_code==201)
        result=client.post('/api/alerts/check',json={}).json()
        ok('no fabricated notifications',result=={'checked':1,'generated':0,'unavailable':1})
        model=client.get('/api/ml/predict').json()
        ok('real historical evaluation',model['prediction']['date']=='2016-01-01' and model['test']['ridge']['mae']==2.101)
        ok('logout invalidates session',client.post('/api/auth/logout',json={}).status_code==200 and client.get('/api/users/me').status_code==401)
    print(json.dumps({'status':'passed','base_url':args.url,'checks':checks},indent=2))


if __name__=='__main__':
    main()
