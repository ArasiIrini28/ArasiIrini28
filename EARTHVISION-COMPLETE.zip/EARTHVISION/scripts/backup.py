"""Consistent SQLite backup/restore; refuses accidental overwrite."""
import argparse
from pathlib import Path
import sqlite3

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('mode',choices=['backup','restore'])
p.add_argument('file',type=Path)
p.add_argument('--database',type=Path,default=Path('earthvision.db'))
a=p.parse_args()
source,target=(a.database,a.file) if a.mode=='backup' else (a.file,a.database)
if not source.is_file():
    raise SystemExit('Source database does not exist.')
if target.exists():
    raise SystemExit('Target exists. Stop EarthVision and move the target to a safe backup location first.')
with sqlite3.connect(source) as src,sqlite3.connect(target) as dst:
    src.backup(dst)
    if dst.execute('PRAGMA integrity_check').fetchone()[0]!='ok':
        raise SystemExit('Database integrity check failed.')
print(f'{a.mode} completed; integrity check passed: {target}')
