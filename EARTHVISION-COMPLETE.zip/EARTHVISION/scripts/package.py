"""Create a reviewable source + prebuilt UI ZIP and verify every archived file hash."""
import argparse
import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
SKIP_DIRS = {'.git', '.venv', 'node_modules', '__pycache__', '.pytest_cache', '.ruff_cache',
             'test-results', 'playwright-report', '.mypy_cache', '.cache'}
SKIP_NAMES = {'.env', '.coverage', 'MANIFEST.sha256'}
SKIP_SUFFIXES = ('.pyc', '.db', '.db-wal', '.db-shm', '.log', '.tsbuildinfo', '.zip')


def candidates():
    for path in sorted(ROOT.rglob('*')):
        relative = path.relative_to(ROOT)
        if any(part in SKIP_DIRS for part in relative.parts) or path.name in SKIP_NAMES:
            continue
        if path.is_symlink():
            raise RuntimeError(f'Symlink not allowed in deliverable: {relative}')
        if path.is_file() and not path.name.endswith(SKIP_SUFFIXES):
            yield path, relative.as_posix()


def package(target):
    target.parent.mkdir(parents=True, exist_ok=True)
    files = list(candidates())
    hashes = {name: hashlib.sha256(path.read_bytes()).hexdigest() for path, name in files}
    manifest = '\n'.join(f'{digest}  {name}' for name, digest in hashes.items())+'\n'
    with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path, name in files:
            archive.write(path, 'EARTHVISION/'+name)
        archive.writestr('EARTHVISION/MANIFEST.sha256', manifest)
    with zipfile.ZipFile(target) as archive:
        assert archive.testzip() is None, 'ZIP CRC check failed'
        for name, digest in hashes.items():
            assert hashlib.sha256(archive.read('EARTHVISION/'+name)).hexdigest() == digest, name
        assert all(not n.startswith('/') and '..' not in Path(n).parts for n in archive.namelist())
        assert not any(n.endswith('/.env') or '/node_modules/' in n or n.endswith('.db') for n in archive.namelist())
    digest = hashlib.sha256(target.read_bytes()).hexdigest()
    target.with_suffix('.zip.sha256').write_text(digest+'  '+target.name+'\n')
    print(f'Verified {len(files)} files, ZIP CRC, per-file SHA-256 and safe paths.')
    print(f'{target} ({target.stat().st_size:,} bytes)\nSHA-256 {digest}')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    package(parser.parse_args().output.resolve())
