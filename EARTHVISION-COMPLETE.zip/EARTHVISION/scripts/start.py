#!/usr/bin/env python3
"""Cross-platform one-command installer and launcher. No cloud services provisioned."""
import os
from pathlib import Path
import shutil
import subprocess
import sys
import venv

ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)
if sys.version_info < (3, 12):
    raise SystemExit('Install free Python 3.12 or newer before running this script.')
if not shutil.which('node') or not shutil.which('npm'):
    raise SystemExit('Install free Node.js 24 LTS (including npm), then rerun.')
if not (ROOT / '.env').exists():
    shutil.copyfile(ROOT / '.env.example', ROOT / '.env')
venv_dir = ROOT / '.venv'
python = venv_dir / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
if not python.exists():
    venv.EnvBuilder(with_pip=True).create(venv_dir)
npm = shutil.which('npm')

def run(args, cwd=ROOT):
    subprocess.run([str(a) for a in args], cwd=cwd, check=True)


try:
    run([python, '-m', 'pip', 'install', '-r', 'backend/requirements.lock'])
    run([npm, 'ci'], ROOT / 'frontend')
    run([npm, 'run', 'build'], ROOT / 'frontend')
    print('\nEarthVision is ready: http://localhost:8000\nAPI docs: http://localhost:8000/docs\nStop with Ctrl+C.\n', flush=True)
    run([python, '-m', 'uvicorn', 'backend.app.main:app', '--host', '127.0.0.1', '--port', '8000'])
except KeyboardInterrupt:
    print('\nEarthVision stopped. Your local database is preserved.')
except subprocess.CalledProcessError as exc:
    raise SystemExit(f'Startup step failed (exit {exc.returncode}). See docs/TROUBLESHOOTING.md; rerun after fixing the issue.')
