"""Probe providers independently; keep credentials out of reports and console output.
Run only after allowing the documented hosts. A failed provider is not activated.
"""
import argparse
from datetime import datetime, timezone, timedelta
import json
from pathlib import Path
import sys
import time
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import httpx
from backend.app.config import settings


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',default='docs/provider-verification.json')
    args=parser.parse_args()
    day=(datetime.now(timezone.utc)-timedelta(days=3)).date().isoformat()
    probes=[
        ('Open-Meteo forecast','https://api.open-meteo.com/v1/forecast',{'latitude':28.61,'longitude':77.2,'current':'temperature_2m'},None,'current',None),
        ('Open-Meteo archive','https://archive-api.open-meteo.com/v1/archive',{'latitude':28.61,'longitude':77.2,'start_date':'2024-01-01','end_date':'2024-01-03','daily':'temperature_2m_max'},None,'daily',None),
        ('Open-Meteo geocoding','https://geocoding-api.open-meteo.com/v1/search',{'name':'London','count':1},None,'results',None),
        ('Open-Meteo CAMS','https://air-quality-api.open-meteo.com/v1/air-quality',{'latitude':28.61,'longitude':77.2,'current':'pm2_5'},None,'current',None),
        ('USGS','https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_day.geojson',None,None,'features',None),
        ('NASA GIBS',f'https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/MODIS_Terra_CorrectedReflectance_TrueColor/default/{day}/GoogleMapsCompatible_Level9/0/0/0.jpg',None,None,'image',None),
        ('NASA FIRMS',f'https://firms.modaps.eosdis.nasa.gov/api/area/csv/{settings.firms_map_key}/VIIRS_NOAA20_NRT/76,27,78,29/1',None,None,'csv','FIRMS_MAP_KEY' if not settings.firms_map_key else None),
        ('OpenAQ','https://api.openaq.org/v3/locations',{'coordinates':'28.61,77.2','radius':25000,'limit':1},{'X-API-Key':settings.openaq_api_key},'results','OPENAQ_API_KEY' if not settings.openaq_api_key else None),
        ('GDACS','https://www.gdacs.org/gdacsapi/api/events/geteventlist/MAP',None,None,'features',None),
        ('OpenStreetMap optional tile','https://tile.openstreetmap.org/0/0/0.png',None,None,'image',None),
        ('RainViewer metadata','https://api.rainviewer.com/public/weather-maps.json',None,None,'radar',None),
        ('RainViewer tiles','https://tilecache.rainviewer.com',None,None,'image','successful radar metadata prerequisite'),
    ]
    results=[]
    radar_tile_url=None
    for name,url,params,headers,expected,missing in probes:
        if name=='RainViewer tiles' and radar_tile_url:
            url,missing=radar_tile_url,None
        row={'provider':name,'host':httpx.URL(url).host,'http_status':None,'verified':False}
        if missing:
            row['error']=(f'Missing optional free key: {missing}; authenticated data not tested.' if missing.endswith('KEY') else 'Radar tile probe skipped because metadata was not verified.')
        else:
            start=time.monotonic()
            try:
                with httpx.Client(timeout=20,follow_redirects=False,headers={'User-Agent':'EarthVision/1.0 (non-commercial academic provider verification)'}) as client:
                    response=client.get(url,params=params,headers=headers)
                row['http_status']=response.status_code
                row['content_type']=response.headers.get('content-type')
                response.raise_for_status()
                valid=(response.headers.get('content-type','').startswith('image/') if expected=='image' else 'latitude' in response.text.splitlines()[0] if expected=='csv' else expected in response.json())
                if name=='RainViewer metadata' and valid:
                    payload=response.json()
                    frames=payload.get('radar',{}).get('past',[])
                    valid=bool(frames) and payload.get('host')=='https://tilecache.rainviewer.com'
                    if valid:
                        import re
                        path=frames[-1]['path']
                        valid=bool(re.fullmatch(r'/v2/radar/[a-zA-Z0-9_-]+',path))
                        if valid:radar_tile_url='https://tilecache.rainviewer.com'+path+'/512/0/0/0/2/1_1.png'
                row['verified']=bool(valid)
                if not valid:row['error']='HTTP success but expected schema/content type was absent.'
            except httpx.HTTPStatusError as exc:
                row['error']=f'HTTP {exc.response.status_code}; provider did not return a successful response.'
            except httpx.ProxyError:
                row['error']='ProxyError: CONNECT denied or proxy unavailable (often HTTP 403); no provider HTTP response.'
            except httpx.TimeoutException:
                row['error']='Request timed out.'
            except (httpx.HTTPError,ValueError,IndexError):
                row['error']='Network, TLS, or response parsing failure; sensitive URL omitted.'
            row['duration_seconds']=round(time.monotonic()-start,2)
        results.append(row)
        print(json.dumps(row),flush=True)
    report={'checked_at':datetime.now(timezone.utc).isoformat(),'policy':'Restricted allowlisted hosts only; TLS verification enabled; no paid services','results':results}
    Path(args.output).write_text(json.dumps(report,indent=2)+'\n')


if __name__=='__main__':
    main()
